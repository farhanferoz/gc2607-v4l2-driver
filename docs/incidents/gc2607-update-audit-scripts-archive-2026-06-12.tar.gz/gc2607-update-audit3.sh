#!/usr/bin/env bash
set +e
line() { printf '\n========== %s ==========\n' "$1"; }
ids=$(dnf history list 2>/dev/null | awk '/2026-06-12/{print $1}')
echo "today's txn ids: $ids"

line "SUSPECT COMPONENTS in today's txns (kernel/microcode/firmware/iwl/nvme/intel/mesa)"
for id in $ids; do
  dnf history info "$id" 2>/dev/null \
    | grep -iE 'kernel|microcode|ucode|linux-firmware|iwlwifi|nvme|intel|mesa|gc2607|ipu' \
    | sed "s/^/[txn $id] /"
done
echo "(nothing above = none touched)"

line "FULL PACKAGE LIST — txn 221 (the 143-pkg update)"
dnf history info 221 2>/dev/null | sed -n '/Packages altered/,$p'
