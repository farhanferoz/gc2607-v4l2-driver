#!/usr/bin/env bash
# Read-only post-update status check. No state changes.
set +e

line() { printf '\n========== %s ==========\n' "$1"; }

line "KERNEL / UPTIME"
echo "running kernel : $(uname -r)"
echo "boot time      : $(who -b 2>/dev/null)"
echo "uptime         : $(uptime -p 2>/dev/null) (since $(uptime -s 2>/dev/null))"

line "LAST REBOOTS / CRASH-vs-SHUTDOWN (last -x)"
last -x 2>/dev/null | grep -E 'reboot|shutdown|crash' | head -n 8

line "CMDLINE (this boot)"
cat /proc/cmdline

line "CSTATE MODE MARKER (/etc/gc2607-cstate-mode)"
cat /etc/gc2607-cstate-mode 2>/dev/null || echo "(marker absent)"

line "C6 disable flag per core (state name + disable; 1=disabled/off)"
for c in $(seq 0 21); do
  d=/sys/devices/system/cpu/cpu$c/cpuidle
  [ -d "$d" ] || continue
  # find the C6 state
  for s in "$d"/state*; do
    nm=$(cat "$s/name" 2>/dev/null)
    if [ "$nm" = "C6" ]; then
      printf 'cpu%-2s C6 disable=%s\n' "$c" "$(cat "$s/disable" 2>/dev/null)"
    fi
  done
done

line "i915 IRQ 200 affinity"
echo "smp_affinity_list: $(cat /proc/irq/200/smp_affinity_list 2>/dev/null || echo '(no irq 200)')"
echo "--- /proc/interrupts i915 line ---"
grep -iE 'i915|^ *200:' /proc/interrupts 2>/dev/null | head

line "BOOT/TELEMETRY SERVICES"
for u in gc2607-cstate-test.service gc2607-cstate-fix.service gc2607-boot-incident.service; do
  printf '%-32s %s\n' "$u" "$(systemctl is-enabled $u 2>/dev/null) / $(systemctl is-active $u 2>/dev/null)"
done
echo "--- user telemetry ---"
systemctl --user is-active gc2607-telemetry.service 2>/dev/null
echo "irqbalance: enabled=$(systemctl is-enabled irqbalance 2>/dev/null) active=$(systemctl is-active irqbalance 2>/dev/null)"

line "INSTALLED KERNELS (rpm)"
rpm -q kernel --qf '%{INSTALLTIME:date}  %{VERSION}-%{RELEASE}.%{ARCH}\n' 2>/dev/null | sort

line "GRUBBY DEFAULT + ARGS PER KERNEL"
echo "default: $(grubby --default-kernel 2>/dev/null)"
for k in $(grubby --info=ALL 2>/dev/null | grep -E '^kernel=' | sed 's/kernel=//;s/"//g'); do
  args=$(grubby --info="$k" 2>/dev/null | grep -E '^args=' | sed 's/args=//')
  echo ">> $k"
  echo "   $args" | grep -oE 'intel_idle[^ "]*' || echo "   (no intel_idle arg)"
done

line "CAMERA MODULE vs RUNNING KERNEL"
echo "gc2607 loaded: $(lsmod 2>/dev/null | grep -c '^gc2607')"
echo "module files for $(uname -r):"
find /lib/modules/$(uname -r)/extra -iname 'gc2607*' -o -iname 'ipu-bridge*' 2>/dev/null | sed 's/^/   /' || echo "   (none in extra)"

line "FREEZE WATCHERS (user timers)"
systemctl --user list-timers 2>/dev/null | grep -E 'gsd-color|gc2607|journal|nvme|i915' | head

line "DONE"
