#!/usr/bin/env bash
# Read-only. Find today's update transaction(s) and inspect for suspect components.
set +e
line() { printf '\n========== %s ==========\n' "$1"; }

line "RECENT DNF TRANSACTIONS"
dnf history list 2>/dev/null | head -n 14

line "TODAY'S TRANSACTIONS (2026-06-12) — full package lists"
ids=$(dnf history list 2>/dev/null | awk -F'|' '$3 ~ /2026-06-12/ {gsub(/ /,"",$1); print $1}')
echo "transaction ids today: $ids"
for id in $ids; do
  printf '\n----- txn %s -----\n' "$id"
  dnf history info "$id" 2>/dev/null | sed -n '/Packages altered/,$p'
done

line "SUSPECT COMPONENTS ACROSS TODAY (kernel/microcode/ucode/firmware/iwl/nvme/i915)"
for id in $ids; do
  dnf history info "$id" 2>/dev/null | grep -iE 'kernel|microcode|ucode|linux-firmware|iwlwifi|nvme|intel-' \
    | sed "s/^/[txn $id] /"
done
echo "(if nothing above this line, today's updates touched none of them)"

line "CURRENT MICROCODE REVISION (live)"
grep -m1 microcode /proc/cpuinfo
echo "rpm microcode_ctl: $(rpm -q microcode_ctl 2>/dev/null)"
