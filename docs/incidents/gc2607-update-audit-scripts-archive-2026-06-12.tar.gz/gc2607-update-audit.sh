#!/usr/bin/env bash
# Read-only. Needs root for /boot (grubby/BLS) + dnf history.
set +e
line() { printf '\n========== %s ==========\n' "$1"; }

line "DEFAULT BOOT KERNEL (what the NEXT reboot would load — informational)"
grubby --default-kernel
echo "saved_entry: $(grep -a '^saved_entry=' /boot/grub2/grubenv 2>/dev/null)"

line "intel_idle cap (Phase-1b PROTECT marker) PER KERNEL"
for v in 7.0.12-201.fc44.x86_64 7.0.11-200.fc44.x86_64 7.0.10-201.fc44.x86_64; do
  printf '%-28s ' "$v"
  grubby --info="/boot/vmlinuz-$v" 2>/dev/null | grep -E '^args=' \
    | grep -oE 'intel_idle[^ "]*' || echo "(no intel_idle cap)"
done

line "LAST DNF TRANSACTION (what today's update changed)"
dnf history info last 2>/dev/null

line "DID IT TOUCH OUR SUSPECT COMPONENTS? (kernel / microcode / firmware)"
dnf history info last 2>/dev/null | grep -iE 'kernel|microcode|ucode|linux-firmware|iwlwifi|nvme|intel' \
  || echo "(none of kernel/microcode/firmware matched in last txn)"

line "DONE"
