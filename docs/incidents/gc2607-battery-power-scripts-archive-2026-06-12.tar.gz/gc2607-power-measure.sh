#!/usr/bin/env bash
# Read-only power MEASUREMENT (no tuning applied). Needs sudo for RAPL + powertop.
# Best result: UNPLUG the charger and DON'T TOUCH the machine for ~90s while it runs.
set +e
WIN=60
line(){ printf '\n========== %s ==========\n' "$1"; }

bat=/sys/class/power_supply/BAT0
line "AC / BATTERY STATE"
ac=$(cat /sys/class/power_supply/A*/online 2>/dev/null | head -1)
echo "AC online   : ${ac:-?}  (0 = on battery = good for this test, 1 = plugged in)"
echo "bat status  : $(cat $bat/status 2>/dev/null)   capacity: $(cat $bat/capacity 2>/dev/null)%"

line "MEASURING for ${WIN}s — leave the machine alone..."
rapl=/sys/class/powercap/intel-rapl:0/energy_uj
maxr=$(cat /sys/class/powercap/intel-rapl:0/max_energy_range_uj 2>/dev/null)
e0=$(cat $rapl 2>/dev/null); b0=$(cat $bat/energy_now 2>/dev/null); t0=$(date +%s.%N)
sleep $WIN
e1=$(cat $rapl 2>/dev/null); b1=$(cat $bat/energy_now 2>/dev/null); t1=$(date +%s.%N)
dt=$(awk "BEGIN{print $t1-$t0}")
echo "elapsed: ${dt}s"

if [ -n "$e0" ] && [ -n "$e1" ]; then
  de=$((e1-e0)); [ "$de" -lt 0 ] 2>/dev/null && de=$((de+maxr))
  echo "RAPL package (CPU+SoC only): $(awk "BEGIN{printf \"%.2f\", $de/1e6/$dt}") W"
else
  echo "RAPL not readable (need sudo)."
fi

if [ -n "$b0" ] && [ -n "$b1" ] && [ "$b1" -lt "$b0" ] 2>/dev/null; then
  db=$((b0-b1))
  echo "TOTAL SYSTEM draw (battery energy delta): $(awk "BEGIN{printf \"%.2f\", $db/1e6/($dt/3600)}") W  <<< the real number"
else
  echo "TOTAL SYSTEM draw: battery not discharging (plugged in?) — unplug + rerun for the real number."
fi

line "POWERTOP — measure only (NO --auto-tune)"
if command -v powertop >/dev/null; then
  powertop --csv=/tmp/gc2607-powertop.csv --time=$WIN >/dev/null 2>&1
  echo "report: /tmp/gc2607-powertop.csv"
  grep -iaE 'baseline|discharge rate|The battery reports' /tmp/gc2607-powertop.csv 2>/dev/null | head
  echo "--- top power-consuming activities ---"
  awk '/Power est/{f=1} f' /tmp/gc2607-powertop.csv 2>/dev/null | head -15
else
  echo "powertop NOT installed. The TOTAL/RAPL numbers above are enough; optional: sudo dnf install powertop"
fi

line "CONTEXT (current power-mgmt state)"
echo "governor : $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)"
echo "EPP      : $(cat /sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference 2>/dev/null)"
echo "backlight: $(awk 'BEGIN{c="/sys/class/backlight/intel_backlight/brightness";m="/sys/class/backlight/intel_backlight/max_brightness"; getline cv<c; getline mv<m; if(mv>0) printf "%d%%", cv*100/mv}')"
echo "PSR arg  : $(grep -o 'i915.enable_psr=[0-9]' /proc/cmdline)"
echo "loadavg  : $(cat /proc/loadavg)"
line "DONE"
