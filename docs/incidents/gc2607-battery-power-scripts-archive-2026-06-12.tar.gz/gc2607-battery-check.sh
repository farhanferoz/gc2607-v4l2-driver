#!/usr/bin/env bash
# Read-only battery health + live draw. No sudo needed.
set +e
line() { printf '\n========== %s ==========\n' "$1"; }

bat=$(ls -d /sys/class/power_supply/BAT* 2>/dev/null | head -1)
ac=$(ls -d /sys/class/power_supply/A{C,DP}* 2>/dev/null | head -1)
echo "battery node: $bat ; ac node: $ac"

g() { cat "$bat/$1" 2>/dev/null; }

line "HEALTH (capacity fade — tests 'battery health' hypothesis)"
# Drivers use either energy_* (uWh) or charge_* (uAh).
fd=$(g energy_full_design); ff=$(g energy_full); unit="uWh"
if [ -z "$fd" ]; then fd=$(g charge_full_design); ff=$(g charge_full); unit="uAh"; fi
echo "design full : $fd $unit"
echo "current full: $ff $unit"
if [ -n "$fd" ] && [ -n "$ff" ] && [ "$fd" -gt 0 ] 2>/dev/null; then
  echo "HEALTH      : $(( ff * 100 / fd ))% of original capacity"
fi
echo "cycle_count : $(g cycle_count)"

line "LIVE STATE (tests 'how much am I drawing right now')"
echo "status      : $(g status)   capacity: $(g capacity)%"
pn=$(g power_now)
if [ -n "$pn" ]; then
  echo "power_now   : $pn uW  = $(awk "BEGIN{printf \"%.2f\", $pn/1000000}") W"
else
  cn=$(g current_now); vn=$(g voltage_now)
  [ -n "$cn" ] && [ -n "$vn" ] && echo "draw (I*V)  : $(awk "BEGIN{printf \"%.2f\", $cn*$vn/1e12}") W"
fi
# crude runtime estimate from current full charge and live draw
if [ -n "$pn" ] && [ "$pn" -gt 0 ] 2>/dev/null && [ -n "$ff" ]; then
  echo "runtime est : $(awk "BEGIN{printf \"%.1f\", $ff/$pn}") h at THIS instant's draw (full charge)"
fi

line "upower summary"
command -v upower >/dev/null && upower -i "$(upower -e | grep -i bat | head -1)" 2>/dev/null \
  | grep -iE 'state|energy|capacity|percentage|time to|rate' || echo "(upower not available)"

line "POWER MANAGEMENT (tests 'Linux power tuning is suboptimal')"
echo "platform_profile: $(cat /sys/firmware/acpi/platform_profile 2>/dev/null)"
command -v powerprofilesctl >/dev/null && echo "power-profiles-daemon: $(powerprofilesctl get 2>/dev/null)"
echo "tlp active   : $(systemctl is-active tlp 2>/dev/null)"
echo "governor     : $(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null)"
echo "EPP (cpu0)   : $(cat /sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference 2>/dev/null)"
echo "EPP spread   :"; for c in 0 2 20; do printf '  cpu%-2s %s\n' "$c" "$(cat /sys/devices/system/cpu/cpu$c/cpufreq/energy_performance_preference 2>/dev/null)"; done
echo "--- C6 mitigation cost (Phase 1b holds these awake = idle-battery hit) ---"
for c in 20 21; do
  for s in /sys/devices/system/cpu/cpu$c/cpuidle/state*; do
    [ "$(cat $s/name 2>/dev/null)" = "C6" ] && printf '  cpu%s C6 disable=%s\n' "$c" "$(cat $s/disable)"
  done
done

line "DISPLAY BACKLIGHT (you noted brightness is low)"
for b in /sys/class/backlight/*; do
  cur=$(cat "$b/brightness" 2>/dev/null); max=$(cat "$b/max_brightness" 2>/dev/null)
  [ -n "$max" ] && [ "$max" -gt 0 ] 2>/dev/null && printf '  %s: %s/%s = %s%%\n' "$(basename $b)" "$cur" "$max" "$(( cur*100/max ))"
done

line "TOP LIVE POWER CONSUMERS (load right now)"
echo "load avg: $(cat /proc/loadavg)"
ps -eo pcpu,comm --sort=-pcpu 2>/dev/null | head -8

line "DONE"
