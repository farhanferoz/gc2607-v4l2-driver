import re, datetime as dt
from Evtx.Evtx import Evtx

def g(xml, pat):
    m = re.search(pat, xml); return m.group(1) if m else ""
def eid(xml):      return g(xml, r"<EventID[^>]*>(\d+)</EventID>")
def provider(xml): return g(xml, r"<Provider Name=[\"']([^\"']*)[\"']")
def ts(xml):       return g(xml, r"<TimeCreated SystemTime=[\"']([^\"']*)[\"']")
def parse_t(s):
    s = s.replace("Z","").split(".")[0]
    try: return dt.datetime.fromisoformat(s)
    except: return None

boots=[]; downs=[]
with Evtx("System.evtx") as log:
    for rec in log.records():
        try: xml = rec.xml()
        except: continue
        p=provider(xml); e=eid(xml); t=parse_t(ts(xml))
        if not t: continue
        if p=="Microsoft-Windows-Kernel-General" and e=="12": boots.append(t)   # OS started
        if p=="Microsoft-Windows-Kernel-General" and e=="13": downs.append(t)   # OS stopped
        if p=="User32" and e=="1074": downs.append(t)                            # clean shutdown req

boots=sorted(set(boots)); downs=sorted(set(downs))
print("Windows OS-start (Kernel-General 12) events:", len(boots))
print("Windows OS-stop  (13/1074) events         :", len(downs))
if boots:
    print("first Windows boot logged:", boots[0])
    print("last  Windows boot logged:", boots[-1])
# pair each boot with the next stop after it -> session length
print("\n=== Windows sessions (boot -> next stop) ===")
total=dt.timedelta(); longest=dt.timedelta(); rows=[]
for b in boots:
    nxt=[d for d in downs if d>=b]
    if nxt:
        dur=nxt[0]-b
        if dur < dt.timedelta(days=2):
            total+=dur; longest=max(longest,dur); rows.append((b,nxt[0],dur))
for b,s,dur in rows[-12:]:
    print("  %s -> %s  = %s" % (b.strftime('%Y-%m-%d %H:%M'), s.strftime('%H:%M'), str(dur)))
print("\nsessions paired:", len(rows))
print("LONGEST single Windows session:", longest, "  (Linux crashes hit at ~19-115 h uptime)")
print("TOTAL Windows uptime (paired)  :", total)
