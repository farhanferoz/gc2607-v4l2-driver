import sys, re
from collections import Counter, defaultdict
from Evtx.Evtx import Evtx

# Event IDs that matter for "did this machine fault under Windows"
INTEREST = {
    "41":   "Kernel-Power 41  = UNEXPECTED shutdown/restart (power loss / hard hang)",
    "6008": "EventLog 6008    = previous shutdown was UNEXPECTED",
    "1001": "BugCheck 1001    = Windows recorded a BSOD crash dump",
    "1074": "1074             = clean shutdown/restart initiated by a process",
    "12":   "Kernel-General12 = OS started (boot)",
    "13":   "Kernel-General13 = OS shutdown",
    "17":   "WHEA 17          = corrected hardware error",
    "18":   "WHEA 18          = FATAL hardware error",
    "19":   "WHEA 19          = corrected hardware error (PCIe/other)",
    "20":   "WHEA 20          = uncorrected/fatal hardware error",
    "46":   "WHEA 46          = error source / PSHED",
    "47":   "WHEA 47          = hardware error (other)",
}

def field(xml, tag):
    m = re.search(r"<%s[^>]*>([^<]*)</%s>" % (tag, tag), xml)
    return m.group(1) if m else ""

def eid(xml):
    m = re.search(r"<EventID[^>]*>(\d+)</EventID>", xml)
    return m.group(1) if m else "?"

def provider(xml):
    m = re.search(r"<Provider Name='([^']*)'", xml)
    return m.group(1) if m else "?"

def ts(xml):
    m = re.search(r"<TimeCreated SystemTime='([^']*)'", xml)
    return m.group(1) if m else "?"

for path in sys.argv[1:]:
    print("\n=== %s ===" % path)
    counts = Counter()
    providers = Counter()
    hits = []
    whea_errs = []
    total = 0
    try:
        with Evtx(path) as log:
            for rec in log.records():
                total += 1
                try: xml = rec.xml()
                except Exception: continue
                e = eid(xml); p = provider(xml)
                counts[e]+=1; providers[p]+=1
                if e in INTEREST and e not in ("12","13"):  # 12/13 too noisy to list
                    hits.append((ts(xml), e, p))
                # capture any WHEA error-source records verbatim-ish
                if "WHEA" in p and e in ("17","18","19","20","47"):
                    whea_errs.append((ts(xml), e, p))
    except Exception as ex:
        print("  parse error:", ex); continue
    print("  total records: %d" % total)
    # interesting-ID summary
    for e,desc in INTEREST.items():
        if counts.get(e):
            print("  [%4sx] %s" % (counts[e], desc))
    # list the actual crash/hardware hits with timestamps (cap 40)
    if hits:
        print("  --- dated crash/HW events (id 41/6008/1001/WHEA) ---")
        for t,e,p in sorted(hits)[:40]:
            print("    %s  id=%s  %s" % (t, e, p))
    else:
        print("  --- no 41 / 6008 / 1001 / WHEA-error events found ---")
