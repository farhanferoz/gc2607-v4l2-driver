import sys, re
from collections import Counter
from Evtx.Evtx import Evtx

def g(xml, pat):
    m = re.search(pat, xml)
    return m.group(1) if m else ""

def eid(xml):      return g(xml, r"<EventID[^>]*>(\d+)</EventID>")
def provider(xml): return g(xml, r"<Provider Name=[\"']([^\"']*)[\"']")
def ts(xml):       return g(xml, r"<TimeCreated SystemTime=[\"']([^\"']*)[\"']")

path = "System.evtx"
# 1) which providers emit EventID 18/19/20/17/41/1001/6008 ?
prov_for_id = {}
counts_by_provid = Counter()
whea = []   # (ts, eid, provider, datatext)
power41 = []
bugcheck = []
unexpected = []
with Evtx(path) as log:
    for rec in log.records():
        try: xml = rec.xml()
        except Exception: continue
        e = eid(xml); p = provider(xml); t = ts(xml)
        if e in ("17","18","19","20","41","1001","6008"):
            counts_by_provid[(p,e)] += 1
        if "WHEA" in p.upper():
            data = " ".join(re.findall(r"<Data[^>]*>([^<]*)</Data>", xml))[:200]
            whea.append((t,e,p,data))
        if p.endswith("Kernel-Power") and e=="41": power41.append((t,e,p))
        if e=="1001" and "BugCheck" in xml: bugcheck.append((t,p))
        if e=="6008": unexpected.append((t,p))

print("=== providers actually emitting ids 17/18/19/20/41/1001/6008 ===")
for (p,e),c in sorted(counts_by_provid.items(), key=lambda x:-x[1]):
    print("  %5dx  id=%-4s  provider=%s" % (c, e, p))

print("\n=== genuine WHEA-Logger records (provider contains WHEA): %d total ===" % len(whea))
# severity by id, WHEA-Logger: 17/19=corrected, 18/20=fatal/uncorrected
sev = {"17":"corrected","18":"FATAL","19":"corrected","20":"UNCORRECTED-FATAL","47":"other"}
byid = Counter(w[1] for w in whea)
for e,c in sorted(byid.items()):
    print("  id=%s (%s): %d" % (e, sev.get(e,'?'), c))
print("\n  --- first + last 6 WHEA records with REAL timestamps + data ---")
ws = sorted([w for w in whea if w[0]])
for t,e,p,data in ws[:6] + [("...","...","...","...")] + ws[-6:]:
    print("    %s  id=%s  %s" % (t, e, data[:140]))
print("\n  timestamp span:", (ws[0][0] if ws else "n/a"), "->", (ws[-1][0] if ws else "n/a"))

print("\n=== hard-crash markers ===")
print("  Kernel-Power 41 (unexpected hard shutdown):", len(power41))
for t,e,p in power41[:20]: print("     ", t)
print("  BugCheck 1001 (BSOD):", len(bugcheck))
for t,p in bugcheck[:20]: print("     ", t)
print("  6008 (previous shutdown unexpected):", len(unexpected))
for t,p in unexpected[:20]: print("     ", t)
