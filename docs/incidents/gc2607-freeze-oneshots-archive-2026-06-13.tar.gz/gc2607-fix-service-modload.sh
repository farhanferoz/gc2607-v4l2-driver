#!/bin/bash
#
# Make gc2607-service.sh accept the xz-compressed module in extra/
# (modprobe loads .ko.xz fine; only the file-existence test was wrong),
# then restart the camera service and verify.
#
set -euo pipefail

SVC=/opt/gc2607/gc2607-service.sh
OLD='if [ -f "/lib/modules/${KVER}/extra/gc2607.ko" ]; then'
NEW='if [ -f "/lib/modules/${KVER}/extra/gc2607.ko" ] || [ -f "/lib/modules/${KVER}/extra/gc2607.ko.xz" ]; then'

if grep -qF "$NEW" "$SVC"; then
    echo "[fix-modload] already patched"
elif grep -qF "$OLD" "$SVC"; then
    cp -a "$SVC" "${SVC}.bak-modload"
    # use awk for an exact-line replacement (sed delimiters get ugly here)
    awk -v old="$OLD" -v new="$NEW" '{ if ($0 ~ /extra\/gc2607\.ko" \]; then/) sub(/if \[ -f "\/lib\/modules\/\$\{KVER\}\/extra\/gc2607\.ko" \]; then/, new); print }' "$SVC" > "${SVC}.tmp"
    grep -qF "$NEW" "${SVC}.tmp" || { echo "[fix-modload] patch failed, aborting" >&2; rm -f "${SVC}.tmp"; exit 1; }
    chmod --reference="$SVC" "${SVC}.tmp"
    mv "${SVC}.tmp" "$SVC"
    echo "[fix-modload] patched $SVC (backup at ${SVC}.bak-modload)"
else
    echo "[fix-modload] expected line not found in $SVC — manual look needed" >&2
    exit 1
fi

systemctl restart gc2607-camera.service
sleep 4
if systemctl is-active --quiet gc2607-camera.service; then
    echo "[fix-modload] OK: gc2607-camera.service active"
    for dev in /dev/media*; do
        if media-ctl -d "$dev" --print-topology 2>/dev/null | grep -qi gc2607; then
            echo "[fix-modload] GC2607 present in $dev topology"
            break
        fi
    done
else
    echo "[fix-modload] service still failing:" >&2
    journalctl -u gc2607-camera.service --no-pager -n 12 >&2
    exit 1
fi
