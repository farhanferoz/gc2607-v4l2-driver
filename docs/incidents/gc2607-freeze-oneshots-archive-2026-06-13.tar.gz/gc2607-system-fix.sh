#!/bin/bash
#
# Silent-freeze remediation, 2026-06-06.
# - Captures NVMe controller diagnostics
# - Reverts the disproven ASPM/APST kernel args (crashes #11/#12 killed the theory)
# - Installs kernel 6.19.14-300.fc44 (F44 GA kernel; the empirically stable series)
#   with the full camera stack (akmods + patched ipu-bridge + gc2607)
# - Arms ramoops (RAM-backed pstore) so any future panic leaves a backtrace
# - Stages the HMB-off experiment on the 7.0.x entries only
# - Makes 6.19.14 the default boot ONLY after verification passes
#
set -euo pipefail
exec > >(tee -a /var/log/gc2607-system-fix.log) 2>&1
echo "=== gc2607-system-fix $(date -Is) ==="

KNEW=6.19.14-300.fc44.x86_64
RPMDIR=/home/ff235/kernel-6.19.14
REPO=/home/ff235/dev/gc2607-v4l2-driver
GC_KO=$RPMDIR/gc2607-build/gc2607.ko
BR_KO=$REPO/ipu-bridge-oot/6.19.14/ipu-bridge.ko

[ -f "$GC_KO" ] && [ -f "$BR_KO" ] || { echo "FATAL: prebuilt 6.19 modules missing"; exit 1; }
[ "$(modinfo -F vermagic "$GC_KO" | awk '{print $1}')" = "$KNEW" ] || { echo "FATAL: gc2607 vermagic mismatch"; exit 1; }
[ "$(modinfo -F vermagic "$BR_KO" | awk '{print $1}')" = "$KNEW" ] || { echo "FATAL: ipu-bridge vermagic mismatch"; exit 1; }

echo "--- Phase 0: NVMe controller diagnostics -> /tmp/nvme-diag.out"
{
  echo "=== smart-log ==="; nvme smart-log /dev/nvme0 || true
  echo "=== error-log (head) ==="; nvme error-log /dev/nvme0 2>/dev/null | head -30 || true
  echo "=== ASPM link state ==="; lspci -s 01:00.0 -vv | grep -E 'LnkCtl:|LnkSta:|L1SubCtl1' || true
  echo "=== HMB ==="; nvme get-feature /dev/nvme0 -f 0x0d -H 2>/dev/null | head -8 || true
} > /tmp/nvme-diag.out
echo "diagnostics captured"

echo "--- Phase 1: revert disproven ASPM/APST args from all kernels"
grubby --update-kernel=ALL --remove-args="pcie_aspm.policy=performance nvme_core.default_ps_max_latency_us=0"

echo "--- Phase 2: dnf installonly_limit -> 4 (protect held-back kernel from eviction)"
if grep -q '^installonly_limit' /etc/dnf/dnf.conf; then
    sed -i 's/^installonly_limit.*/installonly_limit=4/' /etc/dnf/dnf.conf
else
    sed -i '/^\[main\]/a installonly_limit=4' /etc/dnf/dnf.conf
fi
grep installonly_limit /etc/dnf/dnf.conf

echo "--- Phase 3: remove kernel 7.0.9 (oldest, frees a slot)"
dnf -y remove 'kernel*-7.0.9-205.fc44*' 'kmod-*-7.0.9-205.fc44*' 2>&1 | tail -3 || true

echo "--- Phase 4: install kernel $KNEW"
dnf -y install \
  $RPMDIR/kernel-6.19.14-300.fc44.x86_64.rpm \
  $RPMDIR/kernel-core-6.19.14-300.fc44.x86_64.rpm \
  $RPMDIR/kernel-modules-core-6.19.14-300.fc44.x86_64.rpm \
  $RPMDIR/kernel-modules-6.19.14-300.fc44.x86_64.rpm \
  $RPMDIR/kernel-modules-extra-6.19.14-300.fc44.x86_64.rpm \
  $RPMDIR/kernel-devel-6.19.14-300.fc44.x86_64.rpm \
  $RPMDIR/kernel-devel-matched-6.19.14-300.fc44.x86_64.rpm 2>&1 | tail -5

echo "--- Phase 5: akmods (v4l2loopback + intel-ipu6) for $KNEW"
akmods --kernels "$KNEW" || echo "WARNING: akmods reported failure — check /var/cache/akmods/"
ls /lib/modules/$KNEW/extra/ 2>/dev/null || echo "WARNING: no extra/ yet"

echo "--- Phase 6: install patched camera modules for $KNEW"
mkdir -p /lib/modules/$KNEW/extra
xz -c --check=crc32 --lzma2=dict=1MiB "$GC_KO" > /lib/modules/$KNEW/extra/gc2607.ko.xz
xz -c --check=crc32 --lzma2=dict=1MiB "$BR_KO" > /lib/modules/$KNEW/extra/ipu-bridge.ko.xz
depmod "$KNEW"
R1=$(modinfo -k "$KNEW" -F filename gc2607)
R2=$(modinfo -k "$KNEW" -F filename ipu-bridge)
echo "gc2607 -> $R1"; echo "ipu-bridge -> $R2"
case "$R2" in */extra/*) ;; *) echo "FATAL: ipu-bridge not resolving to extra/"; exit 1;; esac

echo "--- Phase 7: arm ramoops (RAM pstore) on all kernels"
echo ramoops > /etc/modules-load.d/ramoops.conf
grubby --update-kernel=ALL --args="reserve_mem=2M:4096:ramoops ramoops.mem_name=ramoops ramoops.record_size=0x20000 ramoops.console_size=0x100000 ramoops.max_reason=2"

echo "--- Phase 8: stage HMB-off experiment on 7.0.x kernels only"
for k in /boot/vmlinuz-7.0.10-201.fc44.x86_64 /boot/vmlinuz-7.0.11-200.fc44.x86_64; do
    [ -f "$k" ] && grubby --update-kernel="$k" --args="nvme.max_host_mem_size_mb=0"
done

echo "--- Phase 9: verify, then flip default boot"
INITRD=/boot/initramfs-$KNEW.img
[ -f "$INITRD" ] || { echo "FATAL: initramfs missing — NOT changing default"; exit 1; }
SZ=$(stat -c %s "$INITRD")
[ "$SZ" -gt 20000000 ] || { echo "FATAL: initramfs suspiciously small ($SZ) — NOT changing default"; exit 1; }
grubby --info=/boot/vmlinuz-$KNEW | head -4
# keep future kernel updates from stealing the default
if grep -q '^UPDATEDEFAULT' /etc/sysconfig/kernel 2>/dev/null; then
    sed -i 's/^UPDATEDEFAULT.*/UPDATEDEFAULT=no/' /etc/sysconfig/kernel
else
    echo 'UPDATEDEFAULT=no' >> /etc/sysconfig/kernel
fi
grubby --set-default=/boot/vmlinuz-$KNEW
echo "Default kernel now: $(grubby --default-kernel)"

echo "=== DONE $(date -Is) — REBOOT REQUIRED to activate 6.19.14 ==="
