#!/bin/bash
#
# gc2607-cstate-fix.sh - Silent-freeze ladder Rung 1: disable deep C-states
# (C6 + C10) GLOBALLY on all cores to defeat Intel Meteor Lake erratum MTL066
# ("Unpredictable System Behavior May Occur When C6 or Deeper Sleep States Are
# Used" - a core may read incorrect data when OTHER cores enter C6 or deeper;
# Intel EDC spec-update 792254). C6 was never globally disabled across crashes
# #1-#15: crash #9 disabled C6 on the GPU-IRQ core only, so the erratum's
# condition (any of the other 21 cores entering C6) stayed live every time.
#
# CORRECT ARG (research 2026-06-08, verified vs kernel source mtl_l_cstates[]
# and this machine's live table state1=C1E state2=C6 state3=C10):
#   intel_idle.max_cstate=1   -> keeps C1E only, kills C6 + C10
#   intel_idle.max_cstate=2   -> WRONG: keeps C1E + C6 (leaves MTL066 live)
# The incident doc's "=2-equivalent" Rung-1 note was wrong; this script uses =1.
#
# Applies three layers so it cannot silently regress:
#   1. live   - write disable=1 to C6/C10 on every core now (this boot, no reboot)
#   2. persist- intel_idle.max_cstate=1 on ALL current kernels (grubby)
#   3. service- gc2607-cstate-fix.service re-asserts the live disable every boot
#               (kernel-agnostic; covers any future kernel installed without the arg)
#
# Usage:
#   sudo ./gc2607-cstate-fix.sh           # apply all three layers
#   sudo ./gc2607-cstate-fix.sh live      # only the live sysfs disable (used by the service)
#   sudo ./gc2607-cstate-fix.sh revert    # undo all three
#
set -u

ARG="intel_idle.max_cstate=1"
SVC=/etc/systemd/system/gc2607-cstate-fix.service
# Self-contained live-disable one-liner (no dependency on this script's path):
LIVE_CMD='for d in /sys/devices/system/cpu/cpu[0-9]*/cpuidle/state2/disable /sys/devices/system/cpu/cpu[0-9]*/cpuidle/state3/disable; do [ -w "$d" ] && echo 1 > "$d"; done'

live_set() {  # $1 = 0 (enable) or 1 (disable)
    local v="$1" n=0 d
    for d in /sys/devices/system/cpu/cpu[0-9]*/cpuidle/state2/disable \
             /sys/devices/system/cpu/cpu[0-9]*/cpuidle/state3/disable; do
        [ -w "$d" ] && echo "$v" > "$d" && n=$((n+1))
    done
    echo "live: wrote disable=$v to $n C6/C10 state files"
}

case "${1:-apply}" in
  live)
    live_set 1
    ;;

  apply)
    # Guard: confirm the cpuidle layout is what we expect before touching it.
    s2=$(cat /sys/devices/system/cpu/cpu0/cpuidle/state2/name 2>/dev/null)
    s3=$(cat /sys/devices/system/cpu/cpu0/cpuidle/state3/name 2>/dev/null)
    echo "cpuidle layout: state2=$s2 state3=$s3 (expect C6 / C10)"
    if [ "$s2" != "C6" ] || [ "$s3" != "C10" ]; then
        echo "ABORT: unexpected cpuidle layout; refusing to touch states." >&2
        exit 1
    fi

    # 1. live
    live_set 1

    # 2. persist on all current kernels
    grubby --update-kernel=ALL --args="$ARG"
    echo "persist: added '$ARG' to all kernel entries (clean from next boot)"

    # 3. boot service (kernel-agnostic belt-and-suspenders)
    cat > "$SVC" <<EOF
[Unit]
Description=gc2607 silent-freeze fix: disable deep C-states (C6+C10) globally (Intel MTL066)
After=multi-user.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c '$LIVE_CMD'

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable gc2607-cstate-fix.service >/dev/null 2>&1
    echo "service: installed + enabled gc2607-cstate-fix.service"

    echo "--- verify live (cpu0) ---"
    grep -H . /sys/devices/system/cpu/cpu0/cpuidle/state2/disable \
              /sys/devices/system/cpu/cpu0/cpuidle/state3/disable
    echo "--- verify persisted (default kernel) ---"
    grubby --info="$(grubby --default-kernel)" | grep -o 'intel_idle.max_cstate=[0-9]' || echo "ARG NOT FOUND on default kernel!"
    ;;

  revert)
    live_set 0
    grubby --update-kernel=ALL --remove-args="$ARG"
    echo "persist: removed '$ARG' from all kernel entries"
    if [ -f "$SVC" ]; then
        systemctl disable --now gc2607-cstate-fix.service >/dev/null 2>&1
        rm -f "$SVC"
        systemctl daemon-reload
        echo "service: removed gc2607-cstate-fix.service"
    fi
    ;;

  *) echo "usage: $0 [apply|live|revert]" >&2; exit 1 ;;
esac
