#!/usr/bin/env bash
#
# gc2607-arm-phase1b.sh - switch the silent-freeze experiment from Phase 1
# (TEST1: only the GPU-IRQ P-core kept awake) to Phase 1b, after Phase 1 wedged
# (crash #17, 2026-06-10 17:23 BST, 8h18m uptime; GPU-IRQ software fix refuted).
#
# Phase 1b hypothesis: it is specifically the LOW-POWER-ISLAND cores (cpu20/21 -
# the only cores capped at 2.5GHz / cluster_id 64) entering C6 that wedges the
# SoC. So: C6 OFF on cpu20+cpu21 only, C6 ON on the other 20 cores; the GPU IRQ
# stays pinned to a P-core (cpu2) so it can never ride a sleeping LP-E core.
#   survive 72h -> a free, permanent 2-core fix (NO warranty); battery + quiet
#                  recovered vs global-off (only 2 of 22 cores stay awake)
#   wedge       -> Phase 2 = HARDWARE -> Huawei warranty, with on-machine proof
#                  that selective C6-off cannot save it
#
# This APPLIES PHASE 1B LIVE (the 72h soak starts now - no reboot required) and
# wires the boot service to re-apply it automatically via /etc/gc2607-cstate-mode.
# The cmdline C6 cap remains the fail-safe: the 7.0.10 entry (cap present) still
# boots fully protected.
#
# Run once, now:   sudo bash gc2607-arm-phase1b.sh
#
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "run with sudo: sudo bash $0"; exit 1; }

REPO=/home/ff235/dev/gc2607-v4l2-driver
SBIN=/usr/local/sbin
MODE_FILE=/etc/gc2607-cstate-mode
KIMG=/boot/vmlinuz-7.0.11-200.fc44.x86_64

echo "== install the updated selective-C-state controller (now understands test1b) =="
install -m 0755 "$REPO/gc2607-cstate-test.sh" "$SBIN/gc2607-cstate-test.sh"
restorecon "$SBIN/gc2607-cstate-test.sh" 2>/dev/null || true

echo "== set the boot-mode marker -> test1b (cmdline cap still wins as the protect fail-safe) =="
echo test1b > "$MODE_FILE"
echo "   $MODE_FILE = $(cat "$MODE_FILE")"

echo "== apply Phase 1b LIVE now (72h soak clock starts) =="
"$SBIN/gc2607-cstate-test.sh" test1b

echo
echo "================ PHASE 1B LIVE - soak clock starts now ================"
echo "Boot path: gc2607-cstate-test.service runs 'apply' -> reads $MODE_FILE -> test1b."
echo "  (7.0.11 entry has no C6 cap = test mode; 7.0.10 fallback keeps the cap = protect.)"
echo
echo "VERDICT in ~72h (~2026-06-13 evening):"
echo "  survive -> LP-E C6 was the culprit: a free permanent 2-core fix, NO warranty."
echo "  wedge   -> hardware confirmed on-machine -> file the Huawei warranty (Phase 2)."
echo
echo "Watch the discriminator live (c6cores should now EXCLUDE 20 and 21):"
echo "  ssh nasff235 \"tail -F /share/homes/ff235/freeze-capture/fedora-journal-\\\$(date +%F).log\" | grep --line-buffered gc2607-telem"
echo
echo "BAIL to full protection at any time (live, no reboot):"
echo "  sudo $SBIN/gc2607-cstate-test.sh protect-now"
echo "Make full protection reboot-surviving too:"
echo "  echo test1 | sudo tee $MODE_FILE >/dev/null"
echo "  sudo grubby --update-kernel=$KIMG --args=intel_idle.max_cstate=1 && sudo reboot"
echo "  (or simply reboot the 7.0.10 entry - it stays fully protected)"
echo "======================================================================"
echo
echo "Optional but recommended: reboot once into 7.0.11 to confirm the boot path"
echo "re-applies test1b on its own, then:  sudo $SBIN/gc2607-cstate-test.sh status"
echo "  (expect: cmdline cap ABSENT, phase mode test1b, i915 IRQ @ cpu2,"
echo "           cpu20 C6=1 / cpu21 C6=1, every other core C6=0)"
