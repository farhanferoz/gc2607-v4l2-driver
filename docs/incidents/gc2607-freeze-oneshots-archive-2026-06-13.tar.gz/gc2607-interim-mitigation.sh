#!/bin/bash
#
# Interim mitigation until the SSD is replaced (decided 2026-06-07, crash #13).
#
# - Hold snap auto-refresh: snapd restart at 08:52:07 was the write burst
#   immediately preceding death #13; refreshes are background write bursts
#   we don't need right now.
# - HMB off on the 6.19.14 entry (nvme.max_host_mem_size_mb=0): the staged
#   experiment from the 7.0.x entries, promoted to interim mitigation -
#   DRAM-less WD drives (SN740/SN770 family) have documented HMB-related
#   crash history. Takes effect on next reboot.
# - Drop crashkernel= from the entry: kdump is disabled (it preempted
#   ramoops and could never save a vmcore); reclaim the 256M reservation.
#
set -u
KVER=6.19.14-300.fc44.x86_64

echo "=== snap refresh hold ==="
snap refresh --hold 2>&1

echo "=== boot entry before ==="
grubby --info=/boot/vmlinuz-$KVER 2>&1 | grep -E "^(kernel|args)"

echo "=== applying args ==="
grubby --update-kernel=/boot/vmlinuz-$KVER \
       --args="nvme.max_host_mem_size_mb=0" \
       --remove-args="crashkernel" 2>&1

echo "=== boot entry after ==="
grubby --info=/boot/vmlinuz-$KVER 2>&1 | grep -E "^(kernel|args)"

echo "=== default boot entry (must stay $KVER) ==="
grubby --default-kernel 2>&1
