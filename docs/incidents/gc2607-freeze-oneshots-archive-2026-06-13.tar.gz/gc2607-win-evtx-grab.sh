#!/bin/bash
#
# gc2607-win-evtx-grab.sh - Read-only grab of the bare-metal Windows event logs
# to check whether Windows ever recorded a hardware fault (WHEA) or an
# unexpected shutdown/bugcheck on THIS machine. Warranty-relevant: a WHEA
# hardware error logged by the OEM OS is OS-independent evidence.
#
# STRICTLY READ-ONLY. Mounts /dev/nvme0n1p3 (NTFS "Windows") with -o ro and
# never writes to it. Copies the relevant .evtx out to a user-readable dir.
#
#   sudo ./gc2607-win-evtx-grab.sh
#
set -u
PART=/dev/nvme0n1p3
MNT=/run/gc2607-winmnt
OUT=/home/ff235/dev/gc2607-v4l2-driver/win-evtx
LOGDIR="Windows/System32/winevt/Logs"

mkdir -p "$MNT" "$OUT"

mounted=0
if mount -o ro "$PART" "$MNT" 2>/dev/null; then
    mounted=1; echo "mounted $PART ro"
elif mount -o ro,force "$PART" "$MNT" 2>/dev/null; then
    mounted=1; echo "mounted $PART ro,force (volume was dirty/hibernated; still read-only)"
else
    echo "ABORT: could not mount $PART read-only" >&2
    exit 1
fi

# Copy the logs that carry crash + hardware-fault evidence.
for f in "System.evtx" \
         "Microsoft-Windows-Kernel-WHEA%4Operational.evtx" \
         "Microsoft-Windows-Kernel-WHEA%4Errors.evtx" \
         "Microsoft-Windows-Kernel-Power%4Thermal-Operational.evtx" \
         "Application.evtx"; do
    src="$MNT/$LOGDIR/$f"
    if [ -f "$src" ]; then
        cp -a "$src" "$OUT/" && echo "GRABBED: $f ($(stat -c%s "$src") bytes)"
    else
        echo "absent : $f"
    fi
done

# Also note last-write time of the Windows dir as a rough 'last used' marker.
echo "--- Windows/System32/config last-modified (rough last-boot marker) ---"
stat -c '%y  %n' "$MNT/Windows/System32/config/SYSTEM" 2>/dev/null || echo "(SYSTEM hive not found)"

[ "$mounted" = 1 ] && umount "$MNT" && echo "unmounted" && rmdir "$MNT" 2>/dev/null
chown -R "${SUDO_UID:-0}:${SUDO_GID:-0}" "$OUT" 2>/dev/null || true
echo "evtx copied to: $OUT"
