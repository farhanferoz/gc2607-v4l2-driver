#!/bin/bash
#
# GC2607 Camera Quick Test
#
# Sets up the media pipeline, captures a frame, and converts to PNG.
#
# Usage:
#   sudo ./gc2607-test.sh              # capture and view
#   sudo ./gc2607-test.sh --no-view    # capture only, skip viewer
#

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="/tmp/gc2607-test"
RAW_FILE="${OUTPUT_DIR}/capture.raw"
PNG_FILE="${OUTPUT_DIR}/capture.png"
BRIGHTNESS="5.0"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
die()   { error "$*"; exit 1; }

# ── Preflight ──────────────────────────────────────────────────────

check_deps() {
    local missing=()

    for cmd in v4l2-ctl media-ctl; do
        if ! command -v "$cmd" &>/dev/null; then
            missing+=("$cmd")
        fi
    done

    if [ ${#missing[@]} -gt 0 ]; then
        die "Missing: ${missing[*]}. Install with: sudo dnf install v4l-utils"
    fi

    if ! command -v python3 &>/dev/null; then
        die "python3 not found."
    fi
}

check_driver() {
    local kver
    kver="$(uname -r)"

    if [ ! -f "/lib/modules/${kver}/extra/gc2607.ko" ]; then
        die "gc2607.ko not found for kernel ${kver}. Kernel was likely updated.\n  Rebuild with: sudo ${SCRIPT_DIR}/gc2607-install.sh"
    fi

    # Check via /proc/modules directly (avoids PATH issues with lsmod)
    if ! grep -q "^gc2607 " /proc/modules; then
        die "gc2607 module not loaded. Run: sudo ${SCRIPT_DIR}/gc2607-reload.sh"
    fi
    info "gc2607 module is loaded."
}

# Find the correct media and video devices
find_devices() {
    local media_dev=""
    local video_dev=""

    # Find media device with IPU6
    for dev in /dev/media*; do
        if media-ctl -d "$dev" --print-topology 2>/dev/null | grep -q "gc2607"; then
            media_dev="$dev"
            break
        fi
    done

    if [ -z "$media_dev" ]; then
        die "gc2607 sensor not found in media topology. A reboot is likely needed for the IPU6 bridge to wire up the sensor. Run: sudo reboot"
    fi

    # Find the capture video device from the topology
    local capture_entity
    capture_entity=$(media-ctl -d "$media_dev" --print-topology 2>/dev/null \
        | grep -A1 "Intel IPU6 ISYS Capture 0" \
        | grep "/dev/video" \
        | grep -o "/dev/video[0-9]*" \
        | head -1) || true

    if [ -z "$capture_entity" ]; then
        # Fallback: try /dev/video0
        video_dev="/dev/video0"
        warn "Could not determine capture device from topology, trying ${video_dev}"
    else
        video_dev="$capture_entity"
    fi

    MEDIA_DEV="$media_dev"
    VIDEO_DEV="$video_dev"
    info "Media device: ${MEDIA_DEV}"
    info "Video device: ${VIDEO_DEV}"
}

# ── Pipeline Setup ─────────────────────────────────────────────────

setup_pipeline() {
    info "Enabling media link..."

    media-ctl -d "$MEDIA_DEV" \
        -l '"Intel IPU6 CSI2 0":1 -> "Intel IPU6 ISYS Capture 0":0[1]' 2>&1 \
        || die "Failed to enable media link."

    info "Setting capture format..."

    v4l2-ctl -d "$VIDEO_DEV" \
        --set-fmt-video=width=1920,height=1080,pixelformat=BA10 2>&1 \
        || die "Failed to set video format."

    info "Pipeline ready."
}

# ── Capture ────────────────────────────────────────────────────────

capture_frame() {
    mkdir -p "$OUTPUT_DIR"

    info "Capturing frame..."

    v4l2-ctl -d "$VIDEO_DEV" \
        --stream-mmap --stream-count=1 --stream-to="$RAW_FILE" 2>&1 \
        || die "Capture failed."

    local size
    size=$(stat -c%s "$RAW_FILE" 2>/dev/null) || die "Raw file not created."

    if [ "$size" -lt 1000 ]; then
        die "Capture file too small (${size} bytes). Sensor may not be streaming."
    fi

    info "Captured ${size} bytes to ${RAW_FILE}"
}

# ── Convert & View ─────────────────────────────────────────────────

convert_and_view() {
    local viewer="${SCRIPT_DIR}/view_raw_wb.py"

    if [ ! -f "$viewer" ]; then
        viewer="${SCRIPT_DIR}/view_raw_bright.py"
    fi

    if [ ! -f "$viewer" ]; then
        warn "No viewer script found. Raw file saved at: ${RAW_FILE}"
        return
    fi

    info "Converting raw Bayer to PNG (brightness=${BRIGHTNESS})..."

    if ! python3 "$viewer" "$RAW_FILE" "$BRIGHTNESS" 2>&1; then
        warn "Conversion failed. Raw file saved at: ${RAW_FILE}"
        return
    fi

    # The viewer scripts output to the same directory as input, with .png extension
    local png_candidate="${RAW_FILE%.raw}.png"
    if [ -f "$png_candidate" ]; then
        PNG_FILE="$png_candidate"
    fi

    if [ ! -f "$PNG_FILE" ]; then
        # Try finding any recent png in the output dir
        PNG_FILE=$(find "$OUTPUT_DIR" -name "*.png" -newer "$RAW_FILE" -print -quit 2>/dev/null) || true
    fi

    if [ -f "$PNG_FILE" ]; then
        info "Image saved to: ${PNG_FILE}"

        if [ "${1:-}" != "--no-view" ]; then
            # Try common image viewers
            for viewer_cmd in feh eog xdg-open; do
                if command -v "$viewer_cmd" &>/dev/null; then
                    info "Opening with ${viewer_cmd}..."
                    "$viewer_cmd" "$PNG_FILE" &
                    return
                fi
            done
            warn "No image viewer found. View manually: feh ${PNG_FILE}"
        fi
    else
        warn "PNG not found after conversion. Raw file at: ${RAW_FILE}"
    fi
}

# ── Main ───────────────────────────────────────────────────────────

main() {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo " GC2607 Camera Test"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""

    check_deps
    check_driver
    find_devices
    setup_pipeline
    capture_frame
    convert_and_view "${1:-}"

    echo ""
    info "Done."
}

main "$@"
