#!/usr/bin/env bash
#
# gc2607-arm-phase1.sh - STAGE the Phase-1 silent-freeze experiment so the ONLY
# remaining action is a reboot. It does NOT change the currently running
# (protected) system: the C6 cap stays on the live cmdline and irqbalance keeps
# running this session. Everything below takes effect on the next boot of 7.0.11.
#
# Run once, now:   sudo bash gc2607-arm-phase1.sh
# Then reboot when ready (in a few hours is fine). Revert printed at the end.
#
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "run with sudo: sudo bash $0"; exit 1; }

REPO=/home/ff235/dev/gc2607-v4l2-driver
SBIN=/usr/local/sbin
KIMG=/boot/vmlinuz-7.0.11-200.fc44.x86_64
UID_FF=$(id -u ff235)

caps() { grubby --info="$KIMG" 2>/dev/null | sed -n 's/^args=//p' | tr ' ' '\n' | grep -c 'intel_idle.max_cstate=1' || true; }

echo "== retire the old global-C6-off service (it would override the selective test) =="
systemctl disable --now gc2607-cstate-fix.service 2>/dev/null || true
systemctl mask gc2607-cstate-fix.service 2>/dev/null || true

echo "== install Phase-1 scripts to a system path (SELinux forbids systemd exec'ing /home) =="
install -m 0755 "$REPO/gc2607-cstate-test.sh"   "$SBIN/gc2607-cstate-test.sh"
install -m 0755 "$REPO/gc2607-boot-incident.sh" "$SBIN/gc2607-boot-incident.sh"
restorecon "$SBIN/gc2607-cstate-test.sh" "$SBIN/gc2607-boot-incident.sh"

echo "== install boot service: selective C-state test (auto-detects mode from cmdline) =="
cat > /etc/systemd/system/gc2607-cstate-test.service <<UNIT
[Unit]
Description=gc2607 Phase-1: selective C6 (GPU-IRQ core kept awake) or protect, per cmdline
After=basic.target
[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=$SBIN/gc2607-cstate-test.sh apply
[Install]
WantedBy=multi-user.target
UNIT

echo "== install boot service: auto-triage if the previous boot wedged =="
cat > /etc/systemd/system/gc2607-boot-incident.service <<UNIT
[Unit]
Description=gc2607 auto-triage when the previous boot did not shut down cleanly
After=network-online.target nas-mount.service
Wants=network-online.target
[Service]
Type=oneshot
ExecStart=$SBIN/gc2607-boot-incident.sh
[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable gc2607-cstate-test.service gc2607-boot-incident.service >/dev/null

echo "== mask irqbalance so the GPU IRQ stays pinned next boot (current session untouched) =="
systemctl mask irqbalance >/dev/null 2>&1 || true

echo "== switch ONLY the 7.0.11 entry to TEST mode (remove the C6 cap) =="
echo "   cap on 7.0.11 before: $(caps)"
grubby --update-kernel="$KIMG" --remove-args="intel_idle.max_cstate=1"
echo "   cap on 7.0.11 after : $(caps)   (0 = test mode armed; fallback kernels + /etc/default/grub keep the cap)"

echo
echo "================ STAGED - reboot is the only remaining step ================"
echo "CURRENT SESSION IS STILL PROTECTED until you reboot:"
echo "   live cmdline cap present : $(grep -c intel_idle.max_cstate=1 /proc/cmdline)  (1 = C6 absent right now)"
echo "   live C6 states on cpu0   : $(for s in /sys/devices/system/cpu/cpu0/cpuidle/state*/name; do cat "$s"; done | tr '\n' ' ')"
echo "ENABLED FOR NEXT BOOT:"
echo "   gc2607-cstate-test       : $(systemctl is-enabled gc2607-cstate-test.service)"
echo "   gc2607-boot-incident     : $(systemctl is-enabled gc2607-boot-incident.service)"
echo "   gc2607-telemetry (user)  : $(runuser -u ff235 -- env XDG_RUNTIME_DIR=/run/user/$UID_FF systemctl --user is-enabled gc2607-telemetry.service 2>/dev/null || echo '?')"
echo "   irqbalance               : $(systemctl is-enabled irqbalance 2>&1 | head -1)  (masked = won't move the GPU IRQ)"
echo
echo "ON NEXT REBOOT of 7.0.11:  GPU IRQ -> cpu2 (P-core, kept awake), C6 ON for the other 21 cores."
echo "  Verify after boot :  sudo $SBIN/gc2607-cstate-test.sh status"
echo "  Watch telemetry   :  ssh nasff235 \"tail -F /share/homes/ff235/freeze-capture/fedora-journal-\\\$(date +%F).log\" | grep --line-buffered gc2607-telem"
echo
echo "REVERT to full protection at any time:"
echo "  sudo grubby --update-kernel=$KIMG --args=intel_idle.max_cstate=1"
echo "  sudo systemctl unmask irqbalance && sudo reboot   # comes back fully protected (C6 absent)"
echo "  no reboot handy? emergency live revert:  sudo $SBIN/gc2607-cstate-test.sh protect-now"
echo "==========================================================================="
