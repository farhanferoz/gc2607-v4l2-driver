#!/bin/bash
#
# Capture one frame from /dev/video50 to /tmp/gc2607-snap.png (and the
# matching telemetry from journalctl) so the dev loop can measure the
# actual ISP output without needing the user to take a screenshot.
#
# Usage:
#   gc2607-snap.sh                 # capture to /tmp/gc2607-snap.png
#
# The ISP only streams when a consumer holds /dev/video50 open; ffmpeg
# acts as that consumer. We capture a few frames and keep the last one
# so AE has time to converge slightly.
#
set -eu

OUT_PNG="${1:-/tmp/gc2607-snap.png}"
SECS="${SECS:-5}"          # how long to stream so AE settles
DEVICE="/dev/video50"

if [ ! -e "$DEVICE" ]; then
    echo "[snap] $DEVICE missing — service not running?" >&2
    exit 1
fi

# Capture: stream for SECS seconds and save the LAST frame.
# -frames:v on its own would grab the first, which is often pre-AE-convergence.
ffmpeg -hide_banner -loglevel error -y \
       -f v4l2 -input_format yuyv422 -video_size 960x540 \
       -i "$DEVICE" -t "$SECS" -update 1 -y "$OUT_PNG"

if [ ! -s "$OUT_PNG" ]; then
    echo "[snap] capture failed" >&2
    exit 1
fi

echo "[snap] saved: $OUT_PNG ($(stat -c %s "$OUT_PNG") bytes, $(identify -format '%wx%h' "$OUT_PNG"))"

# Print the most recent telemetry line so it lines up with this snap.
journalctl -u gc2607-camera.service --since "30 sec ago" --no-pager 2>&1 \
  | grep -E "frames \|" | tail -1
