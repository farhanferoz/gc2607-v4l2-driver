#!/bin/bash
#
# gc2607-deep-sleep.sh - Runtime comfort toggle for deep CPU sleep (C6 + C10).
#
# Background: gc2607-cstate-fix.sh disables C6/C10 globally as the Rung-1
# silent-freeze mitigation (Intel Meteor Lake erratum MTL066). With deep idle
# off, idle cores sit in C1E, so the package runs hot and the fan stays up.
#
# This script is the COMFORT lever - flip deep sleep back ON at runtime when
# you want a cool, quiet machine; OFF to re-assert the mitigation immediately.
#
# SCOPE: live sysfs only (this boot). It deliberately does NOT touch the grub
# arg (intel_idle.max_cstate=1) or gc2607-cstate-fix.service. The freeze
# experiment's boot persistence is left intact, so ANY REBOOT restores the
# C6-off mitigation automatically. "on" therefore means "cool until reboot".
#
# To make deep-sleep-ON survive reboots (i.e. abandon the experiment), use the
# owning script instead:   sudo ./gc2607-cstate-fix.sh revert
#
# Usage:
#   sudo ./gc2607-deep-sleep.sh on       # enable  C6/C10 -> cooler + quieter
#   sudo ./gc2607-deep-sleep.sh off      # disable C6/C10 -> mitigation (hot)
#   sudo ./gc2607-deep-sleep.sh status   # show current live + boot state
#
set -u

# sudo trampoline: re-exec as root if not already (matches the gc2607-*.sh set).
if [ "$(id -u)" -ne 0 ]; then
    exec sudo "$0" "$@"
fi

# Match deep-sleep states by NAME, not index (robust if the table reorders).
# MTL066 covers "C6 or deeper"; on this SoC that is exactly C6 and C10.
DEEP_RE='^(C6|C10)$'

set_deep() {  # $1 = 0 (allow/use) or 1 (block)
    local v="$1" n=0 found=0 d name
    for d in /sys/devices/system/cpu/cpu[0-9]*/cpuidle/state*/; do
        name=$(cat "$d/name" 2>/dev/null) || continue
        [[ "$name" =~ $DEEP_RE ]] || continue
        found=1
        [ -w "${d}disable" ] && echo "$v" > "${d}disable" && n=$((n+1))
    done
    if [ "$found" -eq 0 ]; then
        echo "No C6/C10 idle states exist on this boot." >&2
        echo "The kernel booted with intel_idle.max_cstate=1 (capped at C1E)," >&2
        echo "so deep sleep cannot be toggled live. To bring the states back you" >&2
        echo "must drop that arg and reboot:  sudo ./gc2607-cstate-fix.sh revert" >&2
        return 2
    fi
    echo "live: wrote disable=$v to $n C6/C10 state files"
}

show_status() {
    local cpu d name dis
    echo "=== live deep-sleep state (representative cores) ==="
    for cpu in 0 8 16 20; do
        for d in /sys/devices/system/cpu/cpu$cpu/cpuidle/state*/; do
            name=$(cat "$d/name" 2>/dev/null) || continue
            [[ "$name" =~ $DEEP_RE ]] || continue
            dis=$(cat "${d}disable" 2>/dev/null)
            echo "  cpu$cpu $name disable=$dis  ($([ "$dis" = 0 ] && echo USABLE || echo BLOCKED))"
        done
    done
    echo "=== boot persistence (owned by gc2607-cstate-fix.sh) ==="
    if grep -q 'intel_idle.max_cstate=1' /proc/cmdline; then
        echo "  this-boot cmdline : capped at C1E (C6/C10 absent this boot)"
    else
        echo "  this-boot cmdline : NOT capped (C6/C10 present this boot)"
    fi
    echo "  cstate-fix.service: $(systemctl is-enabled gc2607-cstate-fix.service 2>/dev/null || echo unknown) (re-disables every boot)"
    echo "  next reboot       : mitigation auto-restored (grub arg + service)"
}

case "${1:-status}" in
  on)
    echo ">> Enabling deep sleep (C6+C10): cooler/quieter, freeze experiment PAUSED until reboot"
    set_deep 0
    echo
    show_status
    ;;
  off)
    echo ">> Disabling deep sleep (C6+C10): re-asserting MTL066 mitigation now (hot/noisy)"
    set_deep 1
    echo
    show_status
    ;;
  status)
    show_status
    ;;
  *)
    echo "usage: $0 [on|off|status]" >&2
    exit 1
    ;;
esac
