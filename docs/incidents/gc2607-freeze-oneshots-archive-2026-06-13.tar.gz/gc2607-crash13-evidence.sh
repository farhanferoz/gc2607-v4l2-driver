#!/bin/bash
#
# Crash #13 (2026-06-07 ~08:53) evidence collection + recorder fix.
#
# - Dump /sys/fs/pstore (ramoops) contents, archive anything found
# - Capture NVMe SMART + error log (unsafe_shutdowns should have bumped)
# - Disable kdump: it preempts ramoops in the panic path (crash_kexec runs
#   before kmsg_dump) and can never save a vmcore here (target is the dying
#   disk) - it only destroys evidence. Ramoops becomes the sole recorder.
#
set -u
EV=/var/log/gc2607-crash13
mkdir -p "$EV"

{
    echo "=== $(date -Is) crash #13 evidence ==="

    echo "--- /sys/fs/pstore ---"
    ls -la /sys/fs/pstore/ 2>&1
    for f in /sys/fs/pstore/*; do
        [ -e "$f" ] || continue
        echo "--- archiving $f ---"
        cp -a "$f" "$EV/" 2>&1
    done

    echo "--- /var/lib/systemd/pstore archive ---"
    ls -laR /var/lib/systemd/pstore/ 2>&1

    echo "--- nvme smart-log ---"
    nvme smart-log /dev/nvme0 2>&1

    echo "--- nvme error-log (first entries) ---"
    nvme error-log /dev/nvme0 2>&1 | head -40

    echo "--- disabling kdump ---"
    systemctl disable --now kdump 2>&1
    echo "enabled: $(systemctl is-enabled kdump 2>&1)  active: $(systemctl is-active kdump 2>&1)"
    echo "crash kernel loaded (want 0): $(cat /sys/kernel/kexec_crash_loaded 2>&1)"
} 2>&1 | tee "$EV/report-$(date +%Y%m%d-%H%M%S).txt"
