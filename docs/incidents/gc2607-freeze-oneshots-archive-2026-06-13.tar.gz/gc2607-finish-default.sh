#!/bin/bash
# Finish the steps gc2607-system-fix.sh lost to the head/SIGPIPE at Phase 9:
# UPDATEDEFAULT=no, set default boot to 6.19.14, then print full verification.
set -euo pipefail

KNEW=6.19.14-300.fc44.x86_64

INITRD=/boot/initramfs-$KNEW.img
[ -f "$INITRD" ] || { echo "FATAL: initramfs missing"; exit 1; }
SZ=$(stat -c %s "$INITRD")
[ "$SZ" -gt 20000000 ] || { echo "FATAL: initramfs too small: $SZ"; exit 1; }
echo "initramfs: $SZ bytes OK"

sed -i 's/^UPDATEDEFAULT.*/UPDATEDEFAULT=no/' /etc/sysconfig/kernel
grep ^UPDATEDEFAULT /etc/sysconfig/kernel

grubby --set-default=/boot/vmlinuz-$KNEW
echo "default: $(grubby --default-kernel)"

echo "=== per-kernel args ==="
for k in /boot/vmlinuz-$KNEW /boot/vmlinuz-7.0.11-200.fc44.x86_64 /boot/vmlinuz-7.0.10-201.fc44.x86_64; do
    echo "--- $k"
    grubby --info="$k" | grep ^args= || true
done

echo "=== module sanity ==="
T=$(mktemp -d)
for kv in $KNEW 7.0.11-200.fc44.x86_64; do
    for m in gc2607 ipu-bridge; do
        xz -dc "/lib/modules/$kv/extra/$m.ko.xz" > "$T/$m.ko"
        echo "$kv $m vermagic: $(modinfo -F vermagic "$T/$m.ko")"
    done
done
rm -rf "$T"
ls /lib/modules/$KNEW/extra/v4l2loopback/ /lib/modules/$KNEW/extra/intel-ipu6/ 2>/dev/null | head -12
echo "=== DONE ==="
