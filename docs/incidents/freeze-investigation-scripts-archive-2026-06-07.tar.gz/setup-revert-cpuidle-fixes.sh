#!/usr/bin/env bash
# setup-revert-cpuidle-fixes.sh — back out the DISPROVEN cpuidle / IRQ-pin /
# NVMe-APST mitigations from the silent-freeze investigation.
#
# Crash #9 (2026-06-01) froze with ALL of them live — the fastest freeze in the
# catalog — so they are dead weight: they cost idle power/battery and would
# confound the i915.enable_psr=0 test (we want a clean single variable on the
# next boot). Real cause = an i915 display-resume regression in kernel 7.0; real
# fix = i915.enable_psr=0 (already staged) + a patched kernel. See
# docs/incidents/2026-05-silent-freezes.md (top superseding block + Crash #9).
#
# REVERTS:
#   - gpu-irq-cstate-fix.service  (IRQ200->cpu18 pin + C6/C10 off on cpu18 + irqbalance stop)
#   - disable-ecore-c10.service   (all-core C10 disable)
#   - live C6/C10 disable on every core  -> re-enabled
#   - IRQ200 pin                  -> unpinned + irqbalance restored
#   - nvme_core.default_ps_max_latency_us=0   (kernel cmdline, next boot)
#
# KEEPS ON PURPOSE (these are NOT freeze "fixes"):
#   - mem_sleep_default=s2idle    (separate deep-S3 suspend-hang fix)
#   - nmi_watchdog=panic / crashkernel  (kdump instrumentation)
#   - the NAS journal capture     (how crash #9 was finally observed)
#   - resume=UUID / resume_offset (hibernation — wanted for the long-break mitigation)
#
# Undo this revert: re-run the matching ~/setup-*.sh scripts.

set -uo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "run with sudo: sudo bash $0"; exit 1; }

echo "== 1/4  disable the cpuidle/IRQ-pin services (stop them re-applying each boot)"
for svc in gpu-irq-cstate-fix.service disable-ecore-c10.service; do
  if systemctl disable --now "$svc" 2>/dev/null; then echo "   disabled $svc"; else echo "   (not present: $svc)"; fi
done

echo "== 2/4  re-enable C6 + C10 on every core (live; returns idle power)"
for d in /sys/devices/system/cpu/cpu*/cpuidle/state2/disable \
         /sys/devices/system/cpu/cpu*/cpuidle/state3/disable; do
  echo 0 > "$d" 2>/dev/null || true
done
echo "   done (C6=state2, C10=state3 re-enabled on all cores)"

echo "== 3/4  unpin IRQ 200 and restore irqbalance"
echo 0-21 > /proc/irq/200/smp_affinity_list 2>/dev/null || true
if systemctl enable --now irqbalance 2>/dev/null; then echo "   irqbalance restored"; else echo "   (irqbalance unit not present)"; fi

echo "== 4/4  drop the NVMe APST override from the kernel cmdline (next boot)"
if grubby --update-kernel=ALL --remove-args="nvme_core.default_ps_max_latency_us=0" 2>/dev/null; then
  echo "   removed nvme_core.default_ps_max_latency_us=0"
else
  echo "   (nothing to remove)"
fi

echo
echo "DONE. Live cpuidle/irqbalance are back to stock now; the cmdline change lands"
echo "on the next reboot (the same reboot that activates i915.enable_psr=0)."
echo
echo "Verify now:"
echo "   systemctl is-enabled gpu-irq-cstate-fix.service disable-ecore-c10.service   # -> disabled"
echo "   for c in 0 8 18; do echo cpu\$c C6=\$(cat /sys/devices/system/cpu/cpu\$c/cpuidle/state2/disable) C10=\$(cat /sys/devices/system/cpu/cpu\$c/cpuidle/state3/disable); done   # -> all 0"
echo "Verify after the next reboot:"
echo "   cat /proc/cmdline   # i915.enable_psr=0 present; no nvme_core...; no intel_idle.max_cstate"
