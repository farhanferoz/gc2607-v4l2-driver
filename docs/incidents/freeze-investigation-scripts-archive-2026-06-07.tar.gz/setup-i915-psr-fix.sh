#!/usr/bin/env bash
# setup-i915-psr-fix.sh — silent-freeze mitigation, crash #9 (2026-06-01)
#
# ROOT CAUSE (research-backed, 2026-06-01 — supersedes the cpuidle theory):
#   NOT a CPU idle-state bug. It is an i915 *display* regression in kernel 7.0
#   (Fedora 44). After a MULTI-HOUR s2idle dwell, the eDP link DPLL — the
#   "C10 PLL" in drivers/gpu/drm/i915/display/intel_cx0_phy.c, a DISPLAY PHY
#   that is UNRELATED to the CPU C10 idle state the last three weeks chased
#   (that naming collision is what misdirected the whole investigation) —
#   comes back parked at 61.44 MHz instead of 810 MHz HBR3. The next display
#   atomic commit then hard-hangs pipe A ("Atomic update failure on pipe A")
#   => total silent freeze, power-cycle required.
#   Stable on kernel 6.19.x (Fedora 43); fixed upstream ~v7.1-rc1.
#   Refs: Ubuntu LP#2150605 ; Arch BBS pid=2297604.
#
# WHAT THIS KNOB DOES (and does not):
#   Per LP#2150605, i915.enable_psr=0 converts the HARD HANG into at most a
#   ~5-10 s slow display wake after a long-dwell resume. enable_dc / enable_fbc
#   do NOT affect this code path; psr is the one that does. This is a single
#   clean variable. It is a MITIGATION, not the full fix — the complete fix is a
#   patched kernel (6.19.x, or >=7.1 once Fedora ships it).
#
# Revert:
#   sudo grubby --update-kernel=ALL --remove-args="i915.enable_psr=0" && sudo reboot

set -euo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "run with sudo: sudo bash $0"; exit 1; }

grubby --update-kernel=ALL --args="i915.enable_psr=0"

echo "OK: added i915.enable_psr=0 to all kernel entries (takes effect on next boot)."
echo
echo "Next:"
echo "  1) reboot when your work allows:   sudo reboot"
echo "  2) after reboot, confirm it is live:"
echo "       grep -o 'i915.enable_psr=[0-9]*' /proc/cmdline      # expect: i915.enable_psr=0"
echo "  3) the real test is the NEXT resume from a MULTI-HOUR suspend."
echo "     If the bug is what we think, with psr=0 it should NO LONGER hard-freeze"
echo "     (at worst a 5-10 s slow wake). Check for the tell-tale errors:"
echo "       journalctl -k -b 0 --no-pager | grep -iE 'PHY A|c10pll|pixel_rate|Atomic update failure'"
echo "     - errors present but system recovered  -> confirmed this bug; psr=0 working as mitigation"
echo "     - hard freeze still happens             -> escalate to a patched kernel (6.19.x now / 7.1 later)"
