#!/usr/bin/env bash
# Disable the C10 idle state on ALL cores (cpu0-21). Supersedes the 2026-05-25
# E-core-only (cpu12-21) version. Rationale -- crash #6 (2026-05-26):
#   The 05-25 fix disabled C10 only on the Atom cores (12-21), but the i915 GPU
#   IRQ (IRQ 200) is delivered to a P-core -- cpu3 at crash #5, cpu11 at crash #6 --
#   both with C10 ENABLED. A GPU IRQ arriving at a P-core in deep C10 wedges the
#   display/render pipeline (documented for the same CPU, Core Ultra 9 185H, at
#   archlinux BBS 308313). The E-core-only disable never covered the core the GPU
#   IRQ actually lands on. This extends the disable to every core so the
#   wake-from-C10 path is gone regardless of where any IRQ is steered. Pure
#   cpuidle -- no irqbalance involvement (consistent with the #362 retraction).
# Live (no reboot) + persistent via the existing systemd oneshot unit. Reversible.
#   Revert live:    for c in $(seq 0 21); do echo 0 | sudo tee /sys/devices/system/cpu/cpu$c/cpuidle/state3/disable; done
#   Revert persist: sudo systemctl disable --now disable-ecore-c10.service && sudo rm /etc/systemd/system/disable-ecore-c10.service
#   Restore 05-25 E-core-only scope instead: sudo bash ~/setup-ecore-c10-disable.sh
# Battery note: with C10 off on every core the package cannot reach PC10, so idle
#   power rises. This is the robust "stop the freezes" config. Once a clean week
#   is confirmed, refine to a surgical i915-IRQ pin to reclaim P-core C10.
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "run with sudo"; exit 1; }

CORES="$(seq 0 21)"

apply() {
  for c in $CORES; do
    s=/sys/devices/system/cpu/cpu$c/cpuidle/state3
    [ -d "$s" ] || { echo "WARN cpu$c: no state3"; continue; }
    name=$(cat "$s/name")
    if [ "$name" != "C10" ]; then echo "ABORT cpu$c: state3 is '$name', not C10 -- enumeration changed"; exit 2; fi
    echo 1 > "$s/disable"
  done
}

echo "== applying live (cpu0-21) =="
apply

echo "== updating persistent unit (now all cores) =="
cat > /etc/systemd/system/disable-ecore-c10.service <<'UNIT'
[Unit]
Description=Disable C10 idle state on ALL cores cpu0-21 (silent-freeze mitigation; widened from E-cores-only after crash #6, 2026-05-26)
After=multi-user.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c 'for c in $(seq 0 21); do s=/sys/devices/system/cpu/cpu$c/cpuidle/state3; [ "$(cat $s/name)" = C10 ] && echo 1 > $s/disable; done'

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable disable-ecore-c10.service

echo "== verify (all 22 should read disable=1) =="
ok=1
for c in $CORES; do
  d=$(cat /sys/devices/system/cpu/cpu$c/cpuidle/state3/disable)
  echo "cpu$c state3=$(cat /sys/devices/system/cpu/cpu$c/cpuidle/state3/name) disable=$d"
  [ "$d" = 1 ] || ok=0
done
echo "unit enabled: $(systemctl is-enabled disable-ecore-c10.service)"
[ "$ok" = 1 ] && echo "DONE -- C10 disabled on all cores" || { echo "FAIL -- some core not disabled"; exit 3; }
