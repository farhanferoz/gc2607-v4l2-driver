#!/usr/bin/env bash
#
# setup-gpu-irq-cstate-fix.sh — THE targeted fix for the silent in-use freezes.
#                               (silent-freeze investigation, after crash #8, 2026-06-01)
#
# ROOT CAUSE (research-backed, exact-SoC match — Core Ultra 9 185H / Meteor Lake):
#   The i915 GPU MSI interrupt is delivered to a CPU core that is sitting in a
#   DEEP C-state (C6 or deeper). On Meteor Lake the wake-from-deep-Cstate path is
#   unreliable for the core servicing the GPU IRQ; eventually a delivery hangs, the
#   GPU/display pipeline wedges, and the whole machine freezes with NO kernel log
#   (no code runs to print one). Matches Arch BBS 308313 ("Random freezes on Intel
#   Meteor Lake (i915)") and our own crashes #1-#8.
#
# WHY THE PRIOR FIXES FAILED:
#   - "disable C10" only touched cpuidle state3. C6 (state2) was left ENABLED and is
#     entered ~1.66 MILLION times/boot. A GPU IRQ landing on a core in C6 still wedges.
#     The Arch thread is explicit: "disabling only C10 proved insufficient — deeper
#     states must be disabled on the GPU IRQ core."
#   - IRQBALANCE_BANNED_CPULIST=12-21 made it worse: it FORCES the GPU IRQ onto a
#     C6-enabled P-core (it was on cpu8 at the time of this fix).
#   - NVMe APST / pcie_aspm / docker were red herrings; no kernel version fixes this
#     (community consensus through 7.0-rc), so the 7.0.10 bump couldn't have helped.
#
# THE FIX (surgical, battery-friendly — only ONE core loses deep idle):
#   1. Stop irqbalance (it has only ever fought the pin; our issue #362 concluded it
#      isn't needed here and the ban was counterproductive).
#   2. Pin the i915 (and xe, if present) GPU IRQ to a single dedicated core ($PIN_CPU).
#   3. Disable the DEEP C-states (C6/C8/C10) on that one core only — keep POLL + C1E
#      (C1E wake is a 1us clock-gated halt, never the problem; keeps some power saving).
#   Result: the only core that ever handles the GPU IRQ can never be in a deep state,
#   so the unreliable deep-wake path is removed, while all other 21 cores keep full
#   deep idle for battery.
#
# RUN WITH SUDO:   sudo bash ~/setup-gpu-irq-cstate-fix.sh
#
# REVERT:
#   sudo systemctl disable --now gpu-irq-cstate-fix.service
#   sudo rm /etc/systemd/system/gpu-irq-cstate-fix.service /usr/local/sbin/gpu-irq-cstate-fix
#   sudo systemctl enable --now irqbalance      # if you want it back
#   (C-state disables and the IRQ pin clear on next reboot)
#
# NUCLEAR ALTERNATIVE (if you just want it to stop tonight and don't care about
# battery/heat): add `intel_idle.max_cstate=1` to the kernel cmdline and reboot —
# caps EVERY core at C1E. Heavier on battery but cannot miss. Command:
#   sudo grubby --update-kernel=ALL --args="intel_idle.max_cstate=1" && sudo reboot
set -euo pipefail

PIN_CPU="${PIN_CPU:-18}"   # E-core to dedicate to the GPU IRQ (matches Arch thread's cpu17/18)
WORKER=/usr/local/sbin/gpu-irq-cstate-fix
UNIT=/etc/systemd/system/gpu-irq-cstate-fix.service

if [[ $EUID -ne 0 ]]; then echo "Run with sudo: sudo bash ~/setup-gpu-irq-cstate-fix.sh" >&2; exit 1; fi

echo "=== 1. install the worker that does the pin + C-state disable (re-derives the IRQ each boot) ==="
cat > "$WORKER" <<WORKEREOF
#!/usr/bin/env bash
# Pin the i915/xe GPU IRQ to PIN_CPU and disable deep C-states (C6/C8/C10) on that core.
# Re-derives the IRQ number every boot (MSI numbers are not stable across boots/reloads).
set -u
PIN_CPU=$PIN_CPU

# The GPU IRQ may not be registered the instant this runs; retry for up to ~30s.
irqs=""
for _ in \$(seq 1 30); do
    irqs=\$(awk '/i915|xe/ {gsub(":","",\$1); print \$1}' /proc/interrupts)
    [ -n "\$irqs" ] && break
    sleep 1
done

if [ -n "\$irqs" ]; then
    for irq in \$irqs; do
        echo "\$PIN_CPU" > /proc/irq/\$irq/smp_affinity_list 2>/dev/null \
            && logger -t gpu-irq-cstate-fix "pinned i915/xe IRQ \$irq -> cpu\$PIN_CPU"
    done
else
    logger -t gpu-irq-cstate-fix "WARNING: no i915/xe IRQ found in /proc/interrupts"
fi

# Disable deep C-states (C6/C8/C10) on PIN_CPU only; keep POLL + C1E.
for st in /sys/devices/system/cpu/cpu\$PIN_CPU/cpuidle/state*; do
    name=\$(cat "\$st/name" 2>/dev/null || echo "")
    case "\$name" in
        C6|C8|C10) echo 1 > "\$st/disable" 2>/dev/null \
            && logger -t gpu-irq-cstate-fix "disabled \$name on cpu\$PIN_CPU" ;;
    esac
done
WORKEREOF
chmod 0755 "$WORKER"
echo "wrote $WORKER (PIN_CPU=$PIN_CPU)"

echo "=== 2. stop irqbalance (it only fights the pin; not needed here — see issue #362) ==="
systemctl disable --now irqbalance 2>/dev/null || true
# Drop the counterproductive ban so nothing re-forces the GPU IRQ onto a C6 P-core.
if [ -f /etc/sysconfig/irqbalance ]; then
    sed -i 's/^IRQBALANCE_BANNED_CPULIST=/#IRQBALANCE_BANNED_CPULIST(disabled by gpu-irq-cstate-fix)=/' \
        /etc/sysconfig/irqbalance || true
fi

echo "=== 3. install + enable the boot service ==="
cat > "$UNIT" <<UNITEOF
[Unit]
Description=Pin i915 GPU IRQ to one core and disable deep C-states there (silent-freeze fix, crash #8)
After=multi-user.target
Wants=multi-user.target

[Service]
Type=oneshot
ExecStart=$WORKER
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
UNITEOF
systemctl daemon-reload
systemctl enable --now gpu-irq-cstate-fix.service

echo "=== 4. verify ==="
sleep 2
GPU_IRQ=$(awk '/i915|xe/ {gsub(":","",$1); print $1}' /proc/interrupts | head -1)
echo "GPU IRQ:            ${GPU_IRQ:-NONE}"
echo "  affinity now:     $(cat /proc/irq/${GPU_IRQ}/smp_affinity_list 2>/dev/null)  (want $PIN_CPU)"
echo "  effective now:    $(cat /proc/irq/${GPU_IRQ}/effective_affinity_list 2>/dev/null)"
echo "cpu$PIN_CPU C-states (want C6/C10 disable=1, POLL/C1E disable=0):"
for st in /sys/devices/system/cpu/cpu$PIN_CPU/cpuidle/state*; do
    echo "    $(cat $st/name): disable=$(cat $st/disable)"
done
echo "irqbalance:         $(systemctl is-active irqbalance 2>/dev/null) (want inactive)"
echo
echo "DONE. The GPU IRQ now lives on a core that can never enter a deep C-state."
echo "Watch bar: this is the evidence-based fix. If it survives well past the prior"
echo "worst case (~115h, ~2026-06-06) clean, it's holding. The NAS capture (now per-line"
echo "flushed) will catch the run-up if it ever recurs."
