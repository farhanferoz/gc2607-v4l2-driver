#!/usr/bin/env bash
# Disable the C10 idle state on Meteor Lake E-cores (cpu12-21) as a test of the
# "E-core wake-from-C10 wedges on incoming IRQ" freeze hypothesis.
# Live (no reboot) + persistent via a systemd oneshot unit. Fully reversible.
#   Revert live:   for c in $(seq 12 21); do echo 0 | sudo tee /sys/devices/system/cpu/cpu$c/cpuidle/state3/disable; done
#   Revert persist: sudo systemctl disable --now disable-ecore-c10.service && sudo rm /etc/systemd/system/disable-ecore-c10.service
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "run with sudo"; exit 1; }

ECORES="12 13 14 15 16 17 18 19 20 21"

apply() {
  for c in $ECORES; do
    s=/sys/devices/system/cpu/cpu$c/cpuidle/state3
    [ -d "$s" ] || { echo "WARN cpu$c: no state3"; continue; }
    name=$(cat "$s/name")
    if [ "$name" != "C10" ]; then echo "ABORT cpu$c: state3 is '$name', not C10 — enumeration changed"; exit 2; fi
    echo 1 > "$s/disable"
  done
}

echo "== applying live =="
apply

echo "== installing persistent unit =="
cat > /etc/systemd/system/disable-ecore-c10.service <<'UNIT'
[Unit]
Description=Disable C10 idle state on Meteor Lake E-cores (silent-freeze mitigation, 2026-05-25)
After=multi-user.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c 'for c in 12 13 14 15 16 17 18 19 20 21; do s=/sys/devices/system/cpu/cpu$c/cpuidle/state3; [ "$(cat $s/name)" = C10 ] && echo 1 > $s/disable; done'

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable disable-ecore-c10.service

echo "== verify (all should read disable=1) =="
for c in $ECORES; do echo "cpu$c state3=$(cat /sys/devices/system/cpu/cpu$c/cpuidle/state3/name) disable=$(cat /sys/devices/system/cpu/cpu$c/cpuidle/state3/disable)"; done
echo "unit enabled: $(systemctl is-enabled disable-ecore-c10.service)"
echo "DONE"
