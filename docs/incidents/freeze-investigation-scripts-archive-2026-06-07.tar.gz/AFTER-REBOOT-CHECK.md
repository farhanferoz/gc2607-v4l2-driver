# After-reboot checklist — silent-freeze watch (started 2026-05-31)

Full background: /home/ff235/dev/gc2607-v4l2-driver/docs/incidents/2026-05-silent-freezes.md

-------------------------------------------------------------------
## 1. Is the disk deep-sleep fix live?
    cat /proc/cmdline | tr ' ' '\n' | grep nvme_core
    cat /sys/module/nvme_core/parameters/default_ps_max_latency_us

Expect:  nvme_core.default_ps_max_latency_us=0    and    0
(0 = the SSD is no longer allowed to nap into a deep sleep state.)

-------------------------------------------------------------------
## 2. Is the NAS log capture running?
    systemctl --user is-active journal-capture-nas.service     # -> active
    systemctl --user is-active journal-capture-rotate.timer    # -> active
    ssh nasff235 "tail -2 \$(ls -t /share/homes/ff235/freeze-capture/*-journal-*.log | head -1)"

Expect: both 'active', and log lines timestamped within the last few seconds.
It auto-starts on boot (linger), so this should already be true with no action.

-------------------------------------------------------------------
## 3. ONLY if you just recovered from a FREEZE — grab the evidence first
    ssh nasff235 "tail -300 \$(ls -t /share/homes/ff235/freeze-capture/*-journal-*.log | head -1)"

Look at the last lines before the gap (the freeze moment):
  - "nvme ... I/O timeout" / "reset controller"   -> the disk (APST)         => disk fix wasn't enough
  - "run-docker-netns-... Deactivated" / netns stall -> docker network teardown => stop docker next
  - total silence even on the NAS                  -> deeper CPU/firmware hang  => power-state path

Then start a session and we read it together.

-------------------------------------------------------------------
## Watch bar
Freeze-free past ~115 hours (about 2026-06-05) = the disk fix is working.
Keep docker running for now — it's a single-variable test of the disk fix.

-------------------------------------------------------------------
## If something is OFF
Capture not active:   bash /home/ff235/setup-journal-capture.sh
Disk fix missing:     sudo /home/ff235/setup-nvme-apst-disable.sh   (then reboot)
