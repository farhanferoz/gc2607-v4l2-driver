#!/usr/bin/env bash
# setup-confirm-i915-diagnosis.sh — capture the evidence that CONFIRMS (or refutes)
# the "i915 eDP DPLL parks after a long s2idle dwell" diagnosis for the freezes.
#
# The trick: with i915.enable_psr=0 the bug stops hard-freezing and instead
# SURVIVES + LOGS (a slow wake) — so we can finally observe it without losing the
# machine. That is what makes confirmation possible at all.
#
# USE (run with sudo, on the psr=0 boot):
#   1) BASELINE now, healthy:          sudo bash ~/setup-confirm-i915-diagnosis.sh baseline
#   2) After a LONG suspend (2h+, overnight ideal), the instant you wake it:
#                                      sudo bash ~/setup-confirm-i915-diagnosis.sh post-resume
#   Then compare the two snapshots.
#
# CONFIRMED if post-resume shows ANY of:
#   * dmesg: "Failed to bring PHY A to idle" | "c10pll ... clock: 61440" |
#            "mismatch in pixel_rate" | "Atomic update failure on pipe A"
#   * the eDP link/port clock reading the parked ~61 MHz instead of the baseline rate
#   * last_hw_sleep ~ 0 after a multi-hour suspend (failed S0ix — the precondition)
# REFUTED if, after a genuine 2h+ dwell, post-resume is a clean fast wake with none.

set -uo pipefail
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "run with sudo: sudo bash $0 [baseline|post-resume]"; exit 1; }
tag="${1:-snapshot}"

echo "###### i915 diagnosis capture [$tag] ######"
echo "now: $(date '+%F %T' 2>/dev/null)   uptime: $(uptime -p 2>/dev/null)"
echo "cmdline psr: $(grep -o 'i915.enable_psr=[0-9]*' /proc/cmdline || echo '(not set — psr default ON)')"

echo
echo "== last suspend: did it actually reach HW sleep (S0ix)? =="
for f in last_hw_sleep success fail last_failed_dev last_failed_step; do
  v=$(cat /sys/power/suspend_stats/$f 2>/dev/null) && echo "   $f = $v"
done
echo "   slp_s0_residency_usec = $(cat /sys/kernel/debug/pmc_core/slp_s0_residency_usec 2>/dev/null || echo 'n/a')"
echo "   (last_hw_sleep ~0 after a multi-hour suspend == failed S0ix == the warm/drain precondition)"

echo
echo "== eDP link / DPLL clock (compare baseline-healthy vs post-resume) =="
shown=0
for d in /sys/kernel/debug/dri/*/i915_display_info; do
  [[ -r "$d" ]] || continue
  shown=1; echo "   --- $d ---"
  grep -iE "pipe [A-D]|ENCODER|edp|DPLL|cx0|c10|link|clock|dotclock|hbr|rate" "$d" 2>/dev/null | sed 's/^/     /'
done
[[ $shown -eq 0 ]] && echo "   (i915_display_info not found; try: ls /sys/kernel/debug/dri/*/)"

echo
echo "== signature errors in this boot's kernel log =="
journalctl -k -b 0 --no-pager 2>/dev/null \
  | grep -iE "Failed to bring PHY|c10pll|cx0|pixel_rate|Atomic update failure|PHY [A-Z] Read|flip_done|link training" \
  | tail -40
echo "   ^ empty on baseline = healthy ; populated on post-resume = CONFIRMED"
