#!/bin/bash
# Convert silent freezes into kernel panics so kdump can capture them.
# Run with sudo.
set -euo pipefail

if [ "$EUID" -ne 0 ]; then
    echo "Need root: sudo $0"
    exit 1
fi

echo "=== Step 1: sysctl knobs (live, no reboot) ==="
install -d -m 0755 /etc/sysctl.d
cat > /etc/sysctl.d/99-crash-debug.conf <<'EOF'
# Convert wedged kernel states into panics so kdump fires.
kernel.softlockup_panic = 1
kernel.hung_task_panic  = 1
kernel.hung_task_timeout_secs = 60
kernel.panic_on_oops    = 1
kernel.unknown_nmi_panic = 1
kernel.panic_on_io_nmi  = 1
# After panic, reboot in 10s so the system recovers automatically.
kernel.panic            = 10
# Allow Alt-SysRq for live diagnostics (e.g. SysRq-c forces panic, SysRq-w shows blocked tasks).
kernel.sysrq            = 1
EOF
sysctl --system | tail -20

echo ""
echo "=== Step 2: kernel cmdline additions (takes effect next boot) ==="
# nmi_watchdog=panic  - NMI watchdog fires panic on hard lockup
# watchdog_thresh=10  - 10s threshold (default 10, explicit)
# These are additive; grubby will dedupe if already present.
CURRENT_ARGS=$(cat /proc/cmdline)
echo "Current /proc/cmdline:"
echo "  $CURRENT_ARGS"
echo ""

NEW_ARGS="nmi_watchdog=panic watchdog_thresh=10"
echo "Will add to ALL installed kernels: $NEW_ARGS"
grubby --update-kernel=ALL --args="$NEW_ARGS"

echo ""
echo "=== Step 3: verify kdump still armed ==="
systemctl is-enabled kdump
systemctl is-active kdump
echo "Reserved crashkernel: $(cat /proc/cmdline | tr ' ' '\n' | grep crashkernel || echo 'NOT SET')"

echo ""
echo "=== Done. ==="
echo "Reboot at your convenience to activate watchdog cmdline args."
echo "Live sysctls are already in effect."
echo ""
echo "After next freeze: vmcore will land in /var/crash/<timestamp>/"
echo "Inspect with: crash /usr/lib/debug/lib/modules/\$(uname -r)/vmlinux /var/crash/<dir>/vmcore"
