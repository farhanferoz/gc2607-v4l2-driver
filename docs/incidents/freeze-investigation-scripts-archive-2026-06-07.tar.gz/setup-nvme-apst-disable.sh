#!/usr/bin/env bash
#
# setup-nvme-apst-disable.sh  — silent-freeze mitigation, crash #7 (2026-05-31)
#
# WHY: Crash #7 hit at ~115h uptime WITH all-core C10 disabled and verified live
#      (disable-ecore-c10.service ran on the dead boot, ExecStart covered seq 0 21).
#      That exonerates per-core C10 as the SOLE cause but it clearly helped:
#      time-to-freeze went from 24-48h (crashes #1-#6) to ~115h. Next suspect per
#      the incident plan: WD PC SN740 (SDDPNQE-2T00, fw 74117000) NVMe APST.
#      The kernel already auto-applies "platform quirk: setting simple suspend" to
#      this drive; APST deep states remain ON (default_ps_max_latency_us=100000).
#
# WHAT: Fully disable APST by capping the max allowed exit-latency to 0us, via
#       kernel cmdline (persistent, all kernels). Keeps the all-core C10 disable in
#       place — we are STACKING, not reverting.
#
# REVERT:
#   sudo grubby --update-kernel=ALL --remove-args="nvme_core.default_ps_max_latency_us=0"
#   sudo reboot
#
# Run:  sudo bash ~/setup-nvme-apst-disable.sh   ; then reboot.
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Run with sudo: sudo bash $0" >&2
  exit 1
fi

DEV=/dev/nvme0
echo "==================================================================="
echo " BEFORE — drive identity + current APST state"
echo "==================================================================="
cat /sys/class/nvme/nvme0/model /sys/class/nvme/nvme0/firmware_rev
echo "default_ps_max_latency_us (live module param): $(cat /sys/module/nvme_core/parameters/default_ps_max_latency_us)"
echo
echo "--- APST feature (0x0c) ---"
nvme get-feature "$DEV" -f 0x0c -H 2>&1 | head -40 || true
echo
echo "--- power-state descriptors (entry/exit latency, us) ---"
nvme id-ctrl "$DEV" 2>&1 | grep -iE "^ps |enlat|exlat|mp:|nops" | head -48 || true

echo
echo "==================================================================="
echo " APPLY — add nvme_core.default_ps_max_latency_us=0 to ALL kernels"
echo "==================================================================="
grubby --update-kernel=ALL --args="nvme_core.default_ps_max_latency_us=0"

echo
echo "==================================================================="
echo " VERIFY — arg present on the default kernel"
echo "==================================================================="
if grubby --info=DEFAULT | grep -q "nvme_core.default_ps_max_latency_us=0"; then
  echo "OK: cmdline arg added. Reboot to activate."
else
  echo "FAILED: arg not found in default kernel args." >&2
  exit 1
fi

echo
echo "After reboot, confirm live with:"
echo "  cat /proc/cmdline | tr ' ' '\\n' | grep nvme_core"
echo "  cat /sys/module/nvme_core/parameters/default_ps_max_latency_us   # expect 0"
echo "Then watch for freeze-free uptime past ~115h (the crash #7 mark)."
