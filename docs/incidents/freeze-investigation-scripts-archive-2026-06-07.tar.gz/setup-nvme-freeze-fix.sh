#!/bin/bash
# setup-nvme-freeze-fix.sh — crash #10 root-cause follow-up (2026-06-05)
#
# Diagnosis (see docs/incidents/2026-05-silent-freezes.md, top block):
# the WD PC SN740 NVMe controller drops off the bus (writes stop completing)
# while the rest of the system runs on for ~30s out of page cache, until the
# NVMe I/O timeout fires -> error path -> panic_on_oops -> reboot. Proven for
# #10 (and #9) by NAS-vs-local journal divergence: 32s of entries reached the
# NAS that never reached the local disk.
#
# #9 died with APST already off => APST alone is insufficient. This stages the
# full power-state mitigation set for the SN740 (the community-established fix
# for its controller drops) and runs the controller-side diagnostics.
#
# Cost: ~0.5-1.5W idle battery (no PCIe L1/L1.2, NVMe pinned at PS0).
# Acceptable until a kernel/firmware fix; revert by removing the args.
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo "run with sudo" >&2; exit 1; fi

echo "=== 1/4 NVMe controller-side diagnostics (informational) ==="
smartctl -a /dev/nvme0 | grep -iE 'critical warning|temperature:|percentage used|media and data|error information|unsafe shutdown|power cycle' || true
echo "--- controller error log (non-zero error_count entries) ---"
nvme error-log /dev/nvme0 | grep -B1 -A6 -E 'error_count\s*:\s*[1-9]' | head -40 || echo "(no controller-side error entries)"

echo
echo "=== 2/4 Firmware update check (SN740 fw 74117000; LVFS may have newer) ==="
fwupdmgr refresh --force >/dev/null 2>&1 || true
fwupdmgr get-updates 2>&1 | head -20 || true

echo
echo "=== 3/4 Stage mitigation on kernel cmdline (takes effect next boot) ==="
# APST off (NVMe-internal power states pinned at PS0):
grubby --update-kernel=ALL --args="nvme_core.default_ps_max_latency_us=0"
# PCIe ASPM off (kills L1/L1.2 link states - the layer APST-off does NOT cover,
# and the one most often implicated in SN740 drops):
grubby --update-kernel=ALL --args="pcie_aspm=off"
# Clean up the earlier (superseded) staging: EFI pstore is unusable on this
# firmware (no writable pstore region - established 2026-05); harmless but noise.
grubby --update-kernel=ALL --remove-args="efi_pstore.pstore_disable" 2>/dev/null || true

echo
echo "=== 4/4 Verify staged args ==="
grubby --info=DEFAULT | grep -o 'nvme_core[^ ]*\|pcie_aspm[^ ]*'

echo
echo "Done. Reboot when convenient, then confirm live:"
echo "  cat /sys/module/nvme_core/parameters/default_ps_max_latency_us  # expect 0"
echo "  grep -o 'pcie_aspm=off' /proc/cmdline                           # expect pcie_aspm=off"
echo
echo "Watch bar: the longest pre-crash uptime was ~115h. Freeze-free past"
echo "~5-6 days with these args live is the first real pass signal."
