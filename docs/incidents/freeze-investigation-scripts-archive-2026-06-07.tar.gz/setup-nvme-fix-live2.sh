#!/bin/bash
# setup-nvme-fix-live2.sh — plan B (2026-06-05): ASPM-off live, NO nvme admin
# commands (the set-feature route hung >2min on attempt 1; aborted safely).
# APST-off rides the already-staged boot arg instead and additionally takes
# effect on any controller reset this boot via the module param below.
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo "run with sudo" >&2; exit 1; fi

NVME_PCI=0000:01:00.0

echo "=== BEFORE ==="
lspci -s ${NVME_PCI#0000:} -vv 2>/dev/null | grep -E 'LnkCtl:|L1SubCtl1:' || true

echo
echo "=== ASPM off (live, sysfs only — no drive commands) ==="
echo performance > /sys/module/pcie_aspm/parameters/policy
for f in l0s_aspm l1_aspm l1_1_aspm l1_2_aspm l1_1_pcipm l1_2_pcipm; do
    p="/sys/bus/pci/devices/${NVME_PCI}/link/$f"
    [ -w "$p" ] && echo 0 > "$p" && echo "  $f -> 0"
done

echo
echo "=== APST: module param only (applies if the controller ever resets; ==="
echo "===       the staged boot arg covers the next boot)                 ==="
echo 0 > /sys/module/nvme_core/parameters/default_ps_max_latency_us
cat /sys/module/nvme_core/parameters/default_ps_max_latency_us

echo
echo "=== Fix staged cmdline (pcie_aspm=off -> pcie_aspm.policy=performance) ==="
grubby --update-kernel=ALL --remove-args="pcie_aspm"
grubby --update-kernel=ALL --args="pcie_aspm.policy=performance"
grubby --info=DEFAULT | grep -oE 'nvme_core[^ "]*|pcie_aspm[^ "]*'

echo
echo "=== AFTER (expect: LnkCtl 'ASPM Disabled', L1SubCtl1 all minus) ==="
lspci -s ${NVME_PCI#0000:} -vv 2>/dev/null | grep -E 'LnkCtl:|L1SubCtl1:' || true

echo
echo "ASPM protection LIVE as of $(date '+%F %T'). APST joins at next boot."
