#!/bin/bash
# Move all IRQs off Meteor Lake E-cores (cpu12-21) onto P-cores (cpu0-11).
# Root cause: irqbalance had pinned i915 IRQ to an E-core that enters C10
# between interrupts; the wake-from-C10 path on E-cores is unreliable on
# Meteor Lake, causing silent freezes during active use.
# Run with sudo.
set -euo pipefail

if [ "$EUID" -ne 0 ]; then
    echo "Need root: sudo $0"
    exit 1
fi

CONF=/etc/sysconfig/irqbalance

echo "=== Before ==="
echo "i915 IRQ 200 affinity: $(cat /proc/irq/200/smp_affinity_list)"
echo "  bitmap: $(cat /proc/irq/200/smp_affinity)"
echo ""

echo "=== Updating $CONF ==="
# Remove any prior BANNED_CPULIST line then append ours.
sed -i '/^IRQBALANCE_BANNED_CPULIST=/d' "$CONF"
echo "IRQBALANCE_BANNED_CPULIST=12-21" >> "$CONF"
grep ^IRQBALANCE_BANNED_CPULIST= "$CONF"
echo ""

echo "=== Restarting irqbalance ==="
systemctl restart irqbalance
sleep 8   # let it complete a balance cycle (default interval is 10s)

echo ""
echo "=== After ==="
echo "i915 IRQ 200 affinity: $(cat /proc/irq/200/smp_affinity_list)"
echo "  bitmap: $(cat /proc/irq/200/smp_affinity)"
echo ""

# Sanity check: bitmap should NOT include any of bits 12-21.
HEX=$(cat /proc/irq/200/smp_affinity | tr -d ',')
if [ "$((0x$HEX & 0x3ff000))" -ne 0 ]; then
    echo "WARNING: i915 IRQ still allowed on at least one E-core (cpu12-21)."
    echo "irqbalance may not have re-balanced yet; check again in 60s."
else
    echo "OK: i915 IRQ now restricted to P-cores (cpu0-11)."
fi
echo ""
echo "=== Done. ==="
echo "No reboot required. Setting persists in $CONF across reboots."
echo "If freezes still happen after a week, escalate by also disabling"
echo "C10 on the IRQ-target P-core (we'll know which one after this)."
