#!/usr/bin/env bash
#
# gc2607-fix-phase1.sh - repair the botched Phase-1 launch seen on the
# 2026-06-10 08:38 boot. Two independent defects kept TEST1 from ever running:
#
#   1. SELinux (Enforcing) refused to let systemd exec the boot-service scripts
#      because they live under /home (label user_home_t):
#         gc2607-cstate-test.service: status=203/EXEC "Permission denied"
#      (The old global-off unit dodged this only by running an inline
#       /bin/bash -c loop instead of a /home script.)
#   2. gc2607-arm-phase1.sh never retired the old global-C6-off service
#      (gc2607-cstate-fix.service), so it stayed enabled and re-disabled C6 on
#      ALL cores ~22 s into boot, clobbering the selective test.
#
#   Net effect that boot: C6 was OFF on every core (old mitigation), the GPU IRQ
#   sat on cpu16, and Phase 1 never started.
#
# This script fixes both, then applies TEST1 live and verifies it.
#
# Run once:  sudo bash gc2607-fix-phase1.sh
# Reboot afterwards (recommended) to confirm the boot service brings TEST1 up
# automatically and to start a clean 72 h soak.
#
set -euo pipefail
[ "$(id -u)" -eq 0 ] || exec sudo "$0" "$@"

REPO=/home/ff235/dev/gc2607-v4l2-driver
SBIN=/usr/local/sbin

echo "== 1/5  retire the old global-C6-off service (it was overriding the test) =="
systemctl disable --now gc2607-cstate-fix.service 2>/dev/null || true
systemctl mask gc2607-cstate-fix.service 2>/dev/null || true

echo "== 2/5  install Phase-1 scripts where SELinux lets systemd exec them =="
install -m 0755 "$REPO/gc2607-cstate-test.sh"   "$SBIN/gc2607-cstate-test.sh"
install -m 0755 "$REPO/gc2607-boot-incident.sh" "$SBIN/gc2607-boot-incident.sh"
restorecon -v "$SBIN/gc2607-cstate-test.sh" "$SBIN/gc2607-boot-incident.sh"

echo "== 3/5  repoint both boot units at the system path =="
sed -i "s#ExecStart=.*gc2607-cstate-test.sh#ExecStart=$SBIN/gc2607-cstate-test.sh#"     /etc/systemd/system/gc2607-cstate-test.service
sed -i "s#ExecStart=.*gc2607-boot-incident.sh#ExecStart=$SBIN/gc2607-boot-incident.sh#" /etc/systemd/system/gc2607-boot-incident.service
systemctl daemon-reload
systemctl enable gc2607-cstate-test.service gc2607-boot-incident.service >/dev/null

echo "== 4/5  start the boot service in its real systemd (init_t) context =="
echo "         this both applies TEST1 and proves SELinux now lets systemd exec it"
systemctl restart gc2607-cstate-test.service || true
if systemctl is-active --quiet gc2607-cstate-test.service; then
  echo "   OK: gc2607-cstate-test.service is active -> SELinux exec fix confirmed"
else
  echo "   WARNING: service still not active. Inspect: journalctl -u gc2607-cstate-test.service -b"
fi

echo
echo "== 5/5  verify (expect: cap ABSENT, i915 IRQ @ cpu2, cpu2 C6=1, all others C6=0) =="
"$SBIN/gc2607-cstate-test.sh" status

echo
echo "Phase-1 TEST1 is live; the 72 h soak clock starts now."
echo "Reboot when convenient to confirm the boot service re-applies it automatically:"
echo "   sudo reboot   ;   then:   sudo $SBIN/gc2607-cstate-test.sh status"
echo "Emergency full protection (global C6-off, live):  sudo $SBIN/gc2607-cstate-test.sh protect-now"
